import { Link, useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import AuthLayout from "../layouts/AuthLayout";
import { Input } from "../components/Input";
import Button from "../components/Button";

export default function Login() {
  const navigate = useNavigate();
  return (
    <AuthLayout
      side={{
        quote: "ClariFi finally made me understand what was actually in my mutual fund documents.",
        attribution: "An early ClariFi user",
      }}
    >
      <h1 className="font-display text-2xl font-semibold text-text-primary mb-1.5">Welcome back</h1>
      <p className="text-sm text-text-secondary mb-8">Log in to continue with ClariFi.</p>
      <form className="flex flex-col gap-4" onSubmit={(e) => { e.preventDefault(); navigate("/dashboard"); }}>
        <Input id="email" label="Email" type="email" placeholder="you@example.com" required />
        <Input id="password" label="Password" type="password" placeholder="••••••••" required />
        <div className="flex justify-end -mt-1">
          <a href="#" onClick={(e) => e.preventDefault()} className="text-sm text-accent hover:text-accent/80">
            Forgot password?
          </a>
        </div>
        <Button type="submit" icon={ArrowRight} iconPosition="right" className="mt-2">
          Log in
        </Button>
      </form>
      <p className="text-sm text-text-secondary mt-8">
        New to ClariFi?{" "}
        <Link to="/signup" className="text-accent font-semibold hover:text-accent/80">
          Create an account
        </Link>
      </p>
    </AuthLayout>
  );
}
