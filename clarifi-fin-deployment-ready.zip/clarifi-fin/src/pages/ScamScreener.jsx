import { useState } from "react";
import { ShieldAlert, ScanSearch, RotateCcw, ShieldCheck, AlertCircle } from "lucide-react";
import AppLayout from "../layouts/AppLayout";
import { Card, Badge, Disclaimer } from "../components/Basics";
import Button from "../components/Button";
import { LoadingState } from "../components/States";
import { HighlightedMessage, RiskLevelBanner, RedFlagList, ExplainabilityDrawer } from "../components/ScamAnalyzer";
import { analyzeScamMessage } from "../lib/api";

export default function ScamScreener() {
  const [message, setMessage] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const analyze = async () => {
    if (!message.trim() || loading) return;
    setLoading(true); setError(""); setResult(null);
    try {
      const data = await analyzeScamMessage(message.trim());
      setResult({ ...data, message: message.trim() });
    } catch (err) {
      setError(err.message || "Unable to analyze this message.");
    } finally { setLoading(false); }
  };

  const clear = () => { setMessage(""); setResult(null); setError(""); };
  const scorePct = Math.round((result?.score || 0) * 100);
  const tone = result?.risk_level?.includes("High") ? "danger" : result?.risk_level?.includes("Suspicious") ? "warning" : "positive";

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto px-6 py-10">
        <div className="flex items-start justify-between gap-4 mb-8">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-danger/10 border border-danger/20 flex items-center justify-center"><ShieldAlert size={18} className="text-danger" /></div>
            <div><p className="text-[0.65rem] font-bold tracking-[0.18em] text-text-muted">SECURITY AGENT</p><h1 className="font-display text-2xl font-semibold text-text-primary mt-1">Scam Screener</h1><p className="text-sm text-text-secondary mt-1">Analyze suspicious financial messages before you act.</p></div>
          </div>
          {message && <button onClick={clear} className="inline-flex items-center gap-2 text-xs font-semibold text-text-muted hover:text-text-primary"><RotateCcw size={14}/> Clear</button>}
        </div>

        <div className="grid lg:grid-cols-[1.05fr_0.95fr] gap-5">
          <Card className="p-5 h-fit">
            <div className="flex items-center justify-between mb-3"><div><p className="text-[0.65rem] font-bold tracking-widest text-text-muted">MESSAGE ANALYSIS</p><p className="text-sm font-semibold text-text-primary mt-1">Paste the exact message</p></div><Badge tone="accent">Live analysis</Badge></div>
            <textarea value={message} onChange={e=>setMessage(e.target.value)} rows={12} placeholder="Paste a WhatsApp, Telegram, SMS, email, call transcript, or social-media investment message here..." className="w-full resize-none rounded-xl border border-border bg-bg p-4 outline-none text-sm text-text-primary placeholder:text-text-muted focus:border-accent" />
            <div className="flex items-center justify-between mt-3 mb-4"><span className="text-xs text-text-muted">{message.length.toLocaleString()} characters</span><span className="text-xs text-text-muted">Pattern-based detection</span></div>
            <Button icon={ScanSearch} onClick={analyze} disabled={loading || !message.trim()} className="w-full justify-center">{loading ? "Analyzing..." : "Analyze message"}</Button>
            <Disclaimer className="mt-4" />
          </Card>

          <div>
            {loading && <Card className="p-5"><LoadingState stage={2} /></Card>}
            {!loading && !result && !error && <Card className="p-8 min-h-[420px] flex flex-col items-center justify-center text-center"><ShieldCheck size={28} className="text-text-muted mb-4"/><h2 className="font-display text-lg font-semibold text-text-primary">Your result will appear here</h2><p className="text-sm text-text-muted max-w-sm mt-2 leading-relaxed">ClariFi checks the submitted text against known financial-fraud patterns and explains the signals it finds.</p></Card>}
            {error && <Card className="p-5 border-danger/30 bg-danger/5"><div className="flex gap-3"><AlertCircle className="text-danger shrink-0" size={18}/><div><p className="font-semibold text-sm text-text-primary">Analysis failed</p><p className="text-sm text-text-secondary mt-1">{error}</p></div></div></Card>}
            {result && <Card className="p-6 animate-rise">
              <RiskLevelBanner level={result.risk_level}/>
              <div className="grid sm:grid-cols-2 gap-4 mt-4">
                <div className="rounded-xl border border-border p-4"><p className="text-[0.65rem] font-bold tracking-widest text-text-muted">RISK SCORE</p><p className={`font-display text-3xl font-bold mt-2 ${tone === "danger" ? "text-danger" : tone === "warning" ? "text-warning" : "text-positive"}`}>{scorePct}<span className="text-sm text-text-muted"> / 100</span></p><div className="h-2 bg-white/5 rounded-full mt-3 overflow-hidden"><div className={`h-full rounded-full ${tone === "danger" ? "bg-danger" : tone === "warning" ? "bg-warning" : "bg-positive"}`} style={{width:`${scorePct}%`}}/></div></div>
                <div className="rounded-xl border border-border p-4"><p className="text-[0.65rem] font-bold tracking-widest text-text-muted">SIGNALS</p><p className="font-display text-3xl font-bold text-text-primary mt-2">{result.flags?.length || 0}</p><p className="text-xs text-text-muted mt-1">pattern matches detected</p></div>
              </div>
              <div className="mt-6"><p className="text-[0.65rem] font-bold tracking-widest text-text-muted mb-2">SUBMITTED MESSAGE</p><div className="rounded-xl bg-bg border border-border p-4"><HighlightedMessage message={result.message} flags={result.flags || []}/></div></div>
              <div className="mt-6"><RedFlagList flags={result.flags || []}/></div>
              <ExplainabilityDrawer title="Why was this flagged?"><p className="text-sm text-text-secondary leading-relaxed bg-white/[0.03] rounded-xl p-4">{result.explanation}</p></ExplainabilityDrawer>
              <ExplainabilityDrawer title="How does detection work?"><p className="text-sm text-text-secondary leading-relaxed">{result.detection_notes}</p></ExplainabilityDrawer>
              <div className="mt-5 pt-4 border-t border-border"><Badge tone="positive">Compliance checked</Badge><p className="text-xs text-text-muted mt-2">{result.compliance?.disclaimer}</p></div>
            </Card>}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
