import { useState, useRef, useEffect } from "react";
import { Paperclip, ArrowUp, Plus, Globe2 } from "lucide-react";
import AppLayout from "../layouts/AppLayout";
import { useNavigate } from "react-router-dom";
import { getHistory } from "../lib/api";
import { askClarifi } from "../lib/api";
import { HistoryItem } from "../components/DocumentCard";
import {
  UserBubble,
  AnswerMessage,
  AgentActivityPanel,
} from "../components/ChatMessage";
import { LoadingState } from "../components/States";
import Button from "../components/Button";

export default function Ask() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState([]);
  const [history, setHistory] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [webSearch, setWebSearch] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    getHistory().then(setHistory).catch(() => setHistory([]));
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages, loading]);

  const send = async (text) => {
    const question = (text ?? input).trim();

    if (!question || loading) return;

    // Show user's question immediately
    setMessages((m) => [...m, { type: "user", text: question }]);
    setInput("");
    setError("");
    setLoading(true);

    try {
      // Call the real FastAPI backend
      const response = await askClarifi(question, {
        webSearch: webSearch ? true : null,
      });

      // Convert backend response to the format AnswerMessage expects
      const answerData = {
        answer: response.answer,
        keyTakeaways: response.key_points || [],
        sources: response.sources || [],
        retrievalTrail: (response.trace || []).map(
          (step) => `${step.agent}: ${step.action}`
        ),
      };

      setMessages((m) => [
        ...m,
        {
          type: "answer",
          data: answerData,
        },
      ]);
    } catch (err) {
      console.error("ClariFi Ask error:", err);

      setError(
        err.message ||
          "Unable to connect to the ClariFi backend. Make sure the FastAPI server is running."
      );
    } finally {
      setLoading(false);
    }
  };

  const newConversation = () => {
    setMessages([]);
    setInput("");
    setError("");
  };

  return (
    <AppLayout>
      <div className="flex h-screen">
        {/* Conversation history */}
        <div className="hidden lg:flex flex-col w-72 border-r border-border shrink-0 py-5 px-3 overflow-y-auto">
          <div className="px-2 mb-4">
            <Button
              variant="secondary"
              size="sm"
              icon={Plus}
              className="w-full justify-center"
              onClick={newConversation}
            >
              New conversation
            </Button>
          </div>

          <div className="flex flex-col gap-0.5">
            {history.map((h) => (
              <HistoryItem key={h.id} item={h} />
            ))}
          </div>
        </div>

        {/* Main chat */}
        <div className="flex-1 flex flex-col min-w-0">
          <div
            ref={scrollRef}
            className="flex-1 overflow-y-auto px-4 sm:px-8 py-8"
          >
            <div className="max-w-2xl mx-auto flex flex-col gap-5">
              {/* Empty state */}
              {messages.length === 0 && !loading && (
                <div className="text-center py-20">
                  <h2 className="font-display text-2xl font-semibold text-text-primary mb-2">
                    Ask ClariFi anything
                  </h2>

                  <p className="text-sm text-text-secondary">
                    The Orchestrator routes your question to the right
                    specialist automatically.
                  </p>
                </div>
              )}

              {/* Messages */}
              {messages.map((m, i) =>
                m.type === "user" ? (
                  <UserBubble key={i} text={m.text} />
                ) : (
                  <AnswerMessage key={i} data={m.data} />
                )
              )}

              {/* Loading */}
              {loading && (
                <div className="flex flex-col gap-3 max-w-[92%]">
                  <LoadingState stage={1} />
                  <AgentActivityPanel done={false} />
                </div>
              )}

              {/* Error */}
              {error && (
                <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-300">
                  <p className="font-semibold mb-1">Backend connection error</p>
                  <p>{error}</p>
                </div>
              )}
            </div>
          </div>

          {/* Input */}
          <div className="border-t border-border px-4 sm:px-8 py-4">
            <div className="max-w-2xl mx-auto">
              <div className="flex items-end gap-2 bg-surface border border-border rounded-2xl px-3 py-2 focus-within:border-accent transition-colors">
                <button
                  type="button"
                  onClick={() => navigate("/documents")}
                  className="p-2 text-text-muted hover:text-accent transition-colors"
                  aria-label="Open document library"
                  title="Open document library"
                >
                  <Paperclip size={18} />
                </button>

                <button
                  type="button"
                  onClick={() => setWebSearch((enabled) => !enabled)}
                  className={`p-2 rounded-lg transition-colors ${
                    webSearch
                      ? "text-accent bg-accent/10"
                      : "text-text-muted hover:text-accent"
                  }`}
                  aria-label={webSearch ? "Disable web search" : "Enable web search"}
                  title={webSearch ? "Web search enabled" : "Search the live web"}
                >
                  <Globe2 size={18} />
                </button>

                <textarea
                  rows={1}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      send();
                    }
                  }}
                  placeholder="Ask ClariFi..."
                  className="flex-1 resize-none outline-none bg-transparent text-[0.95rem] text-text-primary placeholder:text-text-muted py-2 max-h-32"
                  disabled={loading}
                />

                <button
                  onClick={() => send()}
                  disabled={loading}
                  className="w-9 h-9 rounded-xl bg-accent hover:bg-accent/90 disabled:opacity-50 text-white flex items-center justify-center transition-colors shrink-0"
                  aria-label="Send"
                >
                  <ArrowUp size={16} />
                </button>
              </div>

              <div className="flex items-center justify-center gap-2 mt-2">
                {webSearch && (
                  <span className="text-[0.7rem] text-accent-cyan">
                    Live web search enabled
                  </span>
                )}
                <p className="text-[0.7rem] text-text-muted text-center">
                  Educational and analytical only — not personalized investment advice.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}