import { Link, useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import AuthLayout from "../layouts/AuthLayout";
import { Input } from "../components/Input";
import Button from "../components/Button";

export default function Signup() {
  const navigate = useNavigate();
  return (
    <AuthLayout
      side={{
        quote: "Understand your investments. See your risk. Spot the red flags.",
        attribution: "ClariFi",
      }}
    >
      <h1 className="font-display text-2xl font-semibold text-text-primary mb-1.5">Create your account</h1>
      <p className="text-sm text-text-secondary mb-8">Start understanding your money, clearly.</p>
      <form className="flex flex-col gap-4" onSubmit={(e) => { e.preventDefault(); navigate("/dashboard"); }}>
        <Input id="name" label="Full name" type="text" placeholder="Rohan Iyer" required />
        <Input id="email" label="Email" type="email" placeholder="you@example.com" required />
        <Input id="password" label="Password" type="password" placeholder="••••••••" required />
        <Button type="submit" icon={ArrowRight} iconPosition="right" className="mt-2">
          Create account
        </Button>
      </form>
      <p className="text-xs text-text-muted mt-6 leading-relaxed">
        ClariFi provides educational and analytical information only, not personalized investment advice.
      </p>
      <p className="text-sm text-text-secondary mt-6">
        Already have an account?{" "}
        <Link to="/login" className="text-accent font-semibold hover:text-accent/80">
          Log in
        </Link>
      </p>
    </AuthLayout>
  );
}
