import AppLayout from "../layouts/AppLayout";
import { Card, Avatar, Disclaimer } from "../components/Basics";
function Section({ title, children }) {
  return (
    <div className="mb-10">
      <h2 className="text-sm font-semibold text-text-secondary mb-3 px-1">{title}</h2>
      <Card className="p-6">{children}</Card>
    </div>
  );
}

export default function Settings() {
  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto px-6 py-10">
        <div className="mb-8">
          <p className="cf-eyebrow mb-2">WORKSPACE</p>
          <h1 className="font-display text-2xl font-semibold text-text-primary">Settings</h1>
          <p className="text-sm text-text-secondary mt-1">Configuration and product status for this local ClariFi workspace.</p>
        </div>

        <Section title="Workspace">
          <div className="flex items-center gap-4">
            <Avatar initials="CF" size={52} />
            <div>
              <p className="text-sm font-semibold text-text-primary">ClariFi User</p>
              <p className="text-xs text-text-secondary mt-0.5">Local workspace · data stays in this backend instance</p>
            </div>
          </div>
        </Section>

        <Section title="Interface">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4 py-2">
              <div>
                <p className="text-sm font-medium text-text-primary">Appearance</p>
                <p className="text-xs text-text-secondary mt-0.5">Black + red dark interface is the active ClariFi design.</p>
              </div>
              <span className="rounded-full bg-accent-soft text-accent px-3 py-1 text-xs font-semibold">Dark</span>
            </div>
            <div className="flex items-center justify-between gap-4 py-2 border-t border-border pt-4">
              <div>
                <p className="text-sm font-medium text-text-primary">Language</p>
                <p className="text-xs text-text-secondary mt-0.5">Response language selection is currently limited to English.</p>
              </div>
              <span className="text-sm font-semibold text-text-primary">English</span>
            </div>
          </div>
        </Section>

        <Section title="Connections">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div><p className="text-sm font-medium text-text-primary">Gemini</p><p className="text-xs text-text-secondary mt-0.5">Used for grounded narration when GEMINI_API_KEY is configured.</p></div>
              <span className="text-xs font-semibold text-text-secondary">Backend configured</span>
            </div>
            <div className="flex items-center justify-between gap-4 border-t border-border pt-4">
              <div><p className="text-sm font-medium text-text-primary">Live web search</p><p className="text-xs text-text-secondary mt-0.5">Tavily credentials are kept server-side and never exposed to the browser.</p></div>
              <span className="text-xs font-semibold text-text-secondary">Backend configured</span>
            </div>
          </div>
        </Section>

        <Section title="About ClariFi">
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-text-primary">Version</span>
            <span className="text-sm text-text-secondary">1.0.0</span>
          </div>
          <Disclaimer className="pt-4 border-t border-border mt-3" />
        </Section>
      </div>
    </AppLayout>
  );
}
