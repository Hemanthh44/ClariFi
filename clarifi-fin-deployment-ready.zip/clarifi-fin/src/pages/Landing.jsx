import { Link } from "react-router-dom";
import { ArrowRight, FileSearch, Activity, PieChart, ShieldAlert } from "lucide-react";
import Logo from "../components/Logo";
import Button from "../components/Button";
import { Card, Badge } from "../components/Basics";
import AgentNetwork from "../components/AgentNetwork";
const agents = [
  { id:"product-explainer", name:"Product Explainer", tagline:"Decode the fine print.", body:"Upload financial documents and ask questions in plain English.", example:"Ask about fees, exclusions, risks, or terms." },
  { id:"risk-simulator", name:"Risk Simulator", tagline:"Model portfolio stress.", body:"Calculate allocation risk and replay historical stress scenarios.", example:"Test your allocation against historical shocks." },
  { id:"summary-agent", name:"Summary Agent", tagline:"See your financial picture.", body:"Generate a concise analytical snapshot from your saved portfolio.", example:"Summarize my portfolio." },
  { id:"scam-screener", name:"Scam Screener", tagline:"Spot financial red flags.", body:"Analyze suspicious messages against known fraud patterns.", example:"Check this investment message." },
];

const agentIcons = {
  "product-explainer": FileSearch,
  "risk-simulator": Activity,
  "summary-agent": PieChart,
  "scam-screener": ShieldAlert,
};

function Nav() {
  return (
    <header className="max-w-6xl mx-auto flex items-center justify-between px-6 py-6">
      <Logo />
      <div className="hidden sm:flex items-center gap-8 text-sm font-medium text-text-secondary">
        <a href="#agents" className="hover:text-text-primary">Specialists</a>
        <a href="#how" className="hover:text-text-primary">How it works</a>
        <a href="#compliance" className="hover:text-text-primary">Compliance</a>
      </div>
      <div className="flex items-center gap-3">
        <Link to="/login" className="text-sm font-medium text-text-secondary hover:text-text-primary hidden sm:block">
          Log in
        </Link>
        <Button as={Link} to="/dashboard" size="sm">Explore ClariFi</Button>
      </div>
    </header>
  );
}

export default function Landing() {
  return (
    <div className="bg-bg min-h-screen">
      <Nav />

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-8 pb-24 grid lg:grid-cols-[1.05fr,0.95fr] gap-14 items-center">
        <div>
          <Badge tone="accent" className="mb-6">Multi-Agent Financial AI</Badge>
          <h1 className="font-display text-[2.6rem] sm:text-[3.3rem] leading-[1.08] font-semibold text-text-primary mb-6">
            Finance,
            <br />
            without the <span className="bg-gradient-to-r from-accent to-accent-cyan bg-clip-text text-transparent">confusion</span>.
          </h1>
          <p className="text-lg text-text-secondary max-w-md mb-8 leading-relaxed">
            ClariFi brings specialized AI agents together to explain financial products, simulate portfolio risk,
            detect scam patterns, and help retail investors make sense of complex financial information.
          </p>
          <div className="flex flex-wrap items-center gap-4 mb-10">
            <Button as={Link} to="/dashboard" size="lg" icon={ArrowRight} iconPosition="right">
              Explore ClariFi
            </Button>
            <a href="#how" className="text-sm font-medium text-text-secondary hover:text-text-primary underline underline-offset-4">
              See how it works
            </a>
          </div>
          <p className="text-xs text-text-muted max-w-md leading-relaxed">
            Educational and analytical only — ClariFi never gives explicit buy/sell recommendations.
          </p>
        </div>
        <div className="flex justify-center">
          <AgentNetwork />
        </div>
      </section>

      {/* One platform, four specialists */}
      <section id="agents" className="max-w-6xl mx-auto px-6 py-20 border-t border-border">
        <p className="text-xs font-bold tracking-widest text-accent-cyan mb-2">ONE PLATFORM</p>
        <h2 className="font-display text-3xl font-semibold text-text-primary mb-12">Four specialists.</h2>
        <div className="grid sm:grid-cols-2 gap-5">
          {agents.map((a) => {
            const Icon = agentIcons[a.id];
            return (
              <Card key={a.id} hover className="p-6">
                <div className="w-11 h-11 rounded-xl bg-accent-soft flex items-center justify-center mb-4">
                  <Icon size={20} className="text-accent" strokeWidth={1.8} />
                </div>
                <h3 className="font-display font-semibold text-text-primary text-lg mb-1.5">{a.name}</h3>
                <p className="text-sm font-medium text-text-secondary mb-2">{a.tagline}</p>
                <p className="text-sm text-text-muted leading-relaxed mb-4">{a.body}</p>
                <p className="text-xs text-accent-cyan">{a.example}</p>
              </Card>
            );
          })}
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="max-w-6xl mx-auto px-6 py-20 border-t border-border">
        <h2 className="font-display text-3xl font-semibold text-text-primary mb-12 max-w-lg">
          Ask one question. ClariFi routes it for you.
        </h2>
        <div className="grid sm:grid-cols-3 gap-8">
          {[
            { step: "01", title: "You ask", body: "\u201cExplain this mutual fund\u201d or \u201cStress test my portfolio.\u201d" },
            { step: "02", title: "Orchestrator routes", body: "ClariFi's Orchestrator Agent selects the right specialist automatically." },
            { step: "03", title: "You get clarity", body: "A grounded, source-cited, compliance-checked answer — in plain language." },
          ].map((s) => (
            <div key={s.step}>
              <span className="font-display text-3xl text-accent/40 block mb-3">{s.step}</span>
              <h3 className="font-medium text-text-primary text-lg mb-2">{s.title}</h3>
              <p className="text-sm text-text-secondary leading-relaxed">{s.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Compliance */}
      <section id="compliance" className="max-w-6xl mx-auto px-6 py-20 border-t border-border">
        <div className="grid lg:grid-cols-[0.9fr,1.1fr] gap-14 items-start">
          <div>
            <Badge tone="positive" className="mb-4">Compliance Checked</Badge>
            <h2 className="font-display text-3xl font-semibold text-text-primary max-w-sm">
              Explainability is a first-class feature, not an afterthought.
            </h2>
          </div>
          <div className="space-y-6">
            {[
              { title: "Source grounded", body: "Every claim traces back to a specific document, page, and section." },
              { title: "Deterministic calculations", body: "Risk scores and numbers come from a Python risk engine — never the language model." },
              { title: "No buy/sell advice", body: "ClariFi stays educational and analytical, always." },
            ].map((b) => (
              <div key={b.title} className="flex gap-4 pb-6 border-b border-border last:border-0 last:pb-0">
                <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2.5 shrink-0" />
                <div>
                  <h3 className="font-medium text-text-primary mb-1">{b.title}</h3>
                  <p className="text-sm text-text-secondary leading-relaxed">{b.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="max-w-6xl mx-auto px-6 pb-24">
        <div className="bg-surface border border-border rounded-xl2 px-8 py-16 sm:py-20 text-center relative overflow-hidden">
          <div className="absolute -top-16 -right-16 w-64 h-64 rounded-full bg-accent/20 blur-3xl" />
          <div className="absolute -bottom-20 -left-10 w-64 h-64 rounded-full bg-accent-cyan/10 blur-3xl" />
          <h2 className="font-display text-3xl sm:text-4xl font-semibold text-text-primary mb-3 relative">
            Understand your investments.
          </h2>
          <p className="text-text-secondary mb-8 relative">See your risk. Spot the red flags.</p>
          <Button as={Link} to="/dashboard" size="lg" className="relative">
            Explore ClariFi
          </Button>
        </div>
      </section>

      <footer className="max-w-6xl mx-auto px-6 py-10 border-t border-border flex items-center justify-between text-sm text-text-muted">
        <Logo size={20} />
        <span>© 2026 ClariFi · Educational & analytical tool, not a registered investment adviser.</span>
      </footer>
    </div>
  );
}
