import { useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  ArrowUpRight,
  CheckCircle2,
  FileSearch,
  FileText,
  ListChecks,
  Loader2,
  MessageCircle,
  Scale,
  ShieldCheck,
  Sparkles,
  Upload,
  X,
} from "lucide-react";

import AppLayout from "../layouts/AppLayout";
import { Card, Badge, ComplianceBadge } from "../components/Basics";
import { UserBubble, AnswerMessage } from "../components/ChatMessage";
import { askProductExplainer, listDocuments, uploadDocument } from "../lib/api";

const actions = [
  {
    id: "ask",
    label: "Ask",
    icon: MessageCircle,
    prompt: "What are the major risks in this financial product?",
  },
  {
    id: "summarize",
    label: "Summarize",
    icon: Sparkles,
    prompt: "Summarize the important information about this financial product.",
  },
  {
    id: "risks",
    label: "Key risks",
    icon: ListChecks,
    prompt: "What are the key risks of this financial product?",
  },
  {
    id: "compare",
    label: "Compare",
    icon: Scale,
    prompt: "What are the important factors I should compare before investing in this financial product?",
  },
];

export default function ProductExplainer() {
  const fileInputRef = useRef(null);

  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [document, setDocument] = useState(null);

  // Restore persisted user uploads after a page refresh. Only user-uploaded documents are used.
  useEffect(() => {
    let active = true;
    listDocuments()
      .then((data) => {
        if (!active) return;
        const docs = data.documents || [];
        if (docs.length) setDocument(docs[docs.length - 1]);
      })
      .catch(() => {
        // The empty state remains usable if the document index is unavailable.
      });
    return () => { active = false; };
  }, []);

  const handleAsk = async (text, action = "ask") => {
    if (!text?.trim() || loading || !document?.id) return;

    setQuestion(text.trim());
    setLoading(true);
    setAnswer(null);
    setError("");

    try {
      const response = await askProductExplainer(text.trim(), {
        documentId: document.id,
        action,
      });

      setAnswer({
        answer: response.answer || "",
        keyTakeaways: response.key_points || [],
        sources: response.sources || [],
        retrievalTrail: (response.trace || []).map(
          (step) => `${step.agent}: ${step.action}`
        ),
      });
    } catch (err) {
      setError(err.message || "Something went wrong while analyzing the document.");
    } finally {
      setLoading(false);
    }
  };

  const handleUploadClick = () => fileInputRef.current?.click();

  const handleUpload = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";

    if (!file) return;

    const allowed = [".pdf", ".txt", ".md"];
    const extension = `.${file.name.split(".").pop()?.toLowerCase()}`;

    if (!allowed.includes(extension)) {
      setError("Please upload a PDF, TXT, or Markdown document.");
      return;
    }

    setUploading(true);
    setError("");
    setAnswer(null);
    setQuestion("");

    try {
      const uploaded = await uploadDocument(file, "Product Explainer");
      setDocument(uploaded);
    } catch (err) {
      setError(err.message || "Document upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const clearDocument = () => {
    if (loading || uploading) return;
    setDocument(null);
    setAnswer(null);
    setQuestion("");
    setError("");
  };

  const runAction = (action) => {
    const selected = actions.find((item) => item.id === action);
    if (selected) handleAsk(selected.prompt, selected.id);
  };

  return (
    <AppLayout>
      <div className="min-h-[calc(100vh-5rem)] bg-[#070708]">
        {/* Header */}
        <header className="border-b border-border bg-bg/80 backdrop-blur-xl sticky top-0 z-20">
          <div className="px-5 sm:px-7 py-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-accent-soft border border-accent/15 flex items-center justify-center shrink-0">
                <FileSearch size={18} className="text-accent" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="font-display font-semibold text-lg text-text-primary">
                    Product Explainer
                  </h1>
                  <Badge tone="cyan">RAG powered</Badge>
                </div>
                <p className="text-xs text-text-muted mt-0.5">
                  Understand financial documents in plain language, with traceable sources.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {document && (
                <div className="hidden sm:flex items-center gap-1.5 text-xs text-positive mr-1">
                  <CheckCircle2 size={14} />
                  Document ready
                </div>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.txt,.md,application/pdf,text/plain,text/markdown"
                onChange={handleUpload}
                className="hidden"
              />

              <button
                type="button"
                onClick={handleUploadClick}
                disabled={uploading}
                className="inline-flex items-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-sm font-semibold text-white shadow-glow hover:brightness-110 transition disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {uploading ? <Loader2 size={15} className="animate-spin" /> : <Upload size={15} />}
                {uploading ? "Uploading..." : "Upload document"}
              </button>
            </div>
          </div>
        </header>

        <main className="p-4 sm:p-6 lg:p-7">
          <div className="max-w-7xl mx-auto">
            {/* Intro */}
            {!document && (
              <Card className="mb-6 overflow-hidden border-accent/15 bg-gradient-to-br from-accent/[0.08] via-surface to-surface">
                <div className="p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                  <div className="max-w-2xl">
                    <Badge tone="accent" className="mb-3">Financial document workspace</Badge>
                    <h2 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight text-text-primary">
                      Turn dense fund documents into decisions you can understand.
                    </h2>
                    <p className="text-sm sm:text-[0.95rem] text-text-secondary leading-relaxed mt-3">
                      Upload a Scheme Information Document, factsheet, or other supported file.
                      ClariFi retrieves relevant sections and explains them without hiding the source material.
                    </p>
                    <div className="flex flex-wrap items-center gap-4 mt-5 text-xs text-text-muted">
                      <span className="inline-flex items-center gap-1.5"><ShieldCheck size={14} className="text-positive" /> Source-grounded</span>
                      <span className="inline-flex items-center gap-1.5"><FileText size={14} className="text-accent-cyan" /> PDF / TXT / MD</span>
                      <span className="inline-flex items-center gap-1.5"><ArrowUpRight size={14} /> Citation-aware</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleUploadClick}
                    className="w-full lg:w-auto shrink-0 inline-flex items-center justify-center gap-2 rounded-xl border border-accent/30 bg-accent-soft px-5 py-3 text-sm font-semibold text-text-primary hover:border-accent/60 hover:bg-accent/15 transition"
                  >
                    <Upload size={16} className="text-accent" />
                    Choose a document
                  </button>
                </div>
              </Card>
            )}

            {/* Workspace */}
            <div className="grid xl:grid-cols-[minmax(300px,0.78fr)_minmax(0,1.22fr)] gap-5">
              {/* Document panel */}
              <section className="min-w-0">
                <Card className="overflow-hidden h-full">
                  <div className="px-5 py-4 border-b border-border flex items-center justify-between gap-3">
                    <div>
                      <p className="text-[0.65rem] font-bold tracking-[0.16em] text-text-muted">SOURCE DOCUMENT</p>
                      <p className="text-sm font-semibold text-text-primary mt-1">Reference material</p>
                    </div>
                    {document && (
                      <button
                        type="button"
                        onClick={clearDocument}
                        className="p-2 rounded-lg text-text-muted hover:text-text-primary hover:bg-white/5 transition"
                        aria-label="Remove selected document"
                        title="Remove selected document"
                      >
                        <X size={16} />
                      </button>
                    )}
                  </div>

                  <div className="p-5">
                    {document ? (
                      <div className="space-y-5">
                        <div className="rounded-2xl border border-border bg-[#070708] p-5">
                          <div className="flex items-start gap-4">
                            <div className="w-11 h-11 rounded-xl bg-accent-soft border border-accent/15 flex items-center justify-center shrink-0">
                              <FileText size={20} className="text-accent" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <h3 className="font-display font-semibold text-text-primary truncate" title={document.name}>
                                {document.name}
                              </h3>
                              <p className="text-xs text-text-muted mt-1">
                                {document.pages || 1} {document.pages === 1 ? "page" : "pages"} · {document.category}
                              </p>
                              <div className="flex items-center gap-1.5 text-xs font-semibold text-positive mt-3">
                                <CheckCircle2 size={14} /> Indexed for retrieval
                              </div>
                            </div>
                          </div>
                        </div>

                        <div>
                          <p className="text-[0.65rem] font-bold tracking-[0.16em] text-text-muted mb-3">WHAT YOU CAN ASK</p>
                          <div className="grid gap-2">
                            {actions.map((action) => {
                              const Icon = action.icon;
                              return (
                                <button
                                  key={action.id}
                                  type="button"
                                  onClick={() => runAction(action.id)}
                                  disabled={loading}
                                  className="group flex items-center gap-3 text-left rounded-xl border border-border bg-white/[0.02] px-3.5 py-3 hover:border-accent/35 hover:bg-accent-soft/40 transition disabled:opacity-50"
                                >
                                  <span className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-accent-soft transition">
                                    <Icon size={15} className="text-text-secondary group-hover:text-accent" />
                                  </span>
                                  <span className="text-sm font-medium text-text-secondary group-hover:text-text-primary">
                                    {action.label}
                                  </span>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        <div className="rounded-xl border border-border bg-white/[0.02] p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <ShieldCheck size={15} className="text-positive" />
                            <span className="text-xs font-semibold text-text-primary">Explainability guardrail</span>
                          </div>
                          <p className="text-xs text-text-muted leading-relaxed">
                            Answers are grounded in the uploaded document and presented as educational analysis, not personalized investment advice.
                          </p>
                        </div>
                      </div>
                    ) : (
                      <div className="min-h-[430px] flex flex-col items-center justify-center text-center px-5">
                        <div className="w-16 h-16 rounded-2xl border border-dashed border-accent/35 bg-accent-soft flex items-center justify-center mb-5">
                          <Upload size={25} className="text-accent" />
                        </div>
                        <h3 className="font-display font-semibold text-text-primary">No document selected</h3>
                        <p className="text-sm text-text-muted leading-relaxed max-w-sm mt-2">
                          Upload a financial document to activate grounded explanations, summaries, risk extraction, and comparisons.
                        </p>
                        <button
                          type="button"
                          onClick={handleUploadClick}
                          className="mt-5 inline-flex items-center gap-2 rounded-xl bg-surface-elevated border border-border px-4 py-2.5 text-sm font-semibold text-text-primary hover:border-accent/40 transition"
                        >
                          <Upload size={15} className="text-accent" />
                          Upload document
                        </button>
                        <p className="text-[0.7rem] text-text-muted mt-3">Maximum file size: 25 MB</p>
                      </div>
                    )}
                  </div>
                </Card>
              </section>

              {/* Conversation panel */}
              <section className="min-w-0">
                <Card className="min-h-[650px] h-full flex flex-col overflow-hidden">
                  <div className="px-5 py-4 border-b border-border flex items-center justify-between gap-4">
                    <div className="min-w-0">
                      <p className="text-[0.65rem] font-bold tracking-[0.16em] text-text-muted">CLARIFI ANALYSIS</p>
                      <p className="text-sm font-semibold text-text-primary mt-1 truncate">
                        {document ? document.name : "Upload a document to begin"}
                      </p>
                    </div>
                    {answer && <ComplianceBadge />}
                  </div>

                  <div className="flex-1 p-5 sm:p-6 overflow-y-auto">
                    {!document && !error && (
                      <div className="min-h-[500px] flex flex-col items-center justify-center text-center">
                        <div className="w-12 h-12 rounded-xl bg-white/5 border border-border flex items-center justify-center mb-4">
                          <Sparkles size={20} className="text-text-muted" />
                        </div>
                        <h3 className="font-display font-semibold text-text-primary">Your explanation will appear here</h3>
                        <p className="text-sm text-text-muted mt-2 max-w-md leading-relaxed">
                          Upload a document, then ask a question or use one of the focused analysis actions.
                        </p>
                      </div>
                    )}

                    {document && !question && !loading && !answer && !error && (
                      <div className="min-h-[500px] flex flex-col items-center justify-center text-center">
                        <div className="w-14 h-14 rounded-2xl bg-accent-soft border border-accent/15 flex items-center justify-center mb-4">
                          <MessageCircle size={22} className="text-accent" />
                        </div>
                        <h3 className="font-display text-lg font-semibold text-text-primary">Ask about your document</h3>
                        <p className="text-sm text-text-muted mt-2 max-w-md leading-relaxed">
                          Try a question below, or use the focused actions in the document panel.
                        </p>
                        <div className="flex flex-wrap justify-center gap-2 mt-5">
                          {actions.slice(0, 3).map((action) => (
                            <button
                              key={action.id}
                              type="button"
                              onClick={() => runAction(action.id)}
                              className="text-xs font-medium text-text-secondary border border-border bg-white/[0.02] rounded-full px-3 py-2 hover:text-text-primary hover:border-accent/40 transition"
                            >
                              {action.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="max-w-3xl mx-auto space-y-5">
                      {question && <UserBubble text={question} />}

                      {loading && (
                        <Card className="p-5 border-accent/15 bg-accent-soft/[0.35]">
                          <div className="flex items-center gap-3">
                            <Loader2 size={17} className="text-accent animate-spin" />
                            <div>
                              <p className="text-sm font-semibold text-text-primary">Analyzing your document</p>
                              <p className="text-xs text-text-muted mt-0.5">Retrieving relevant sections and generating a grounded explanation...</p>
                            </div>
                          </div>
                        </Card>
                      )}

                      {!loading && answer && <AnswerMessage data={answer} />}

                      {!loading && error && (
                        <div className="rounded-2xl border border-danger/30 bg-danger/10 p-4 flex gap-3">
                          <AlertCircle size={18} className="text-danger shrink-0 mt-0.5" />
                          <div>
                            <p className="font-semibold text-sm text-text-primary">Something went wrong</p>
                            <p className="text-sm text-text-secondary mt-1 leading-relaxed">{error}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="border-t border-border p-4 sm:p-5 bg-bg/60">
                    <div className="max-w-3xl mx-auto">
                      <div className={`flex items-end gap-2 rounded-2xl border bg-surface p-2 transition ${document ? "border-border focus-within:border-accent/50 focus-within:shadow-glow" : "border-border/70 opacity-70"}`}>
                        <textarea
                          value={question}
                          onChange={(e) => setQuestion(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" && !e.shiftKey) {
                              e.preventDefault();
                              handleAsk(question, "ask");
                            }
                          }}
                          disabled={!document || loading}
                          rows={1}
                          placeholder={document ? "Ask anything about this financial product..." : "Upload a document to start asking questions"}
                          className="flex-1 resize-none bg-transparent px-3 py-2 text-sm text-text-primary placeholder:text-text-muted outline-none min-h-[40px] max-h-28"
                        />
                        <button
                          type="button"
                          onClick={() => handleAsk(question, "ask")}
                          disabled={!document || !question.trim() || loading}
                          className="shrink-0 inline-flex items-center justify-center rounded-xl bg-accent w-10 h-10 text-white hover:brightness-110 transition disabled:opacity-40 disabled:cursor-not-allowed"
                          aria-label="Ask ClariFi"
                        >
                          {loading ? <Loader2 size={16} className="animate-spin" /> : <ArrowUpRight size={17} />}
                        </button>
                      </div>
                      <p className="text-[0.68rem] text-text-muted text-center mt-2">
                        Enter to ask · Shift + Enter for a new line · Answers are educational and source-grounded
                      </p>
                    </div>
                  </div>
                </Card>
              </section>
            </div>
          </div>
        </main>
      </div>
    </AppLayout>
  );
}
