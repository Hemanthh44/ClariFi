import { useState } from "react";
import { Activity, RotateCcw, ShieldCheck } from "lucide-react";
import AppLayout from "../layouts/AppLayout";
import { Card, Badge, Disclaimer } from "../components/Basics";
import { RiskScoreCard } from "../components/RiskScore";
import StressTestTimeMachine from "../components/StressTestTimeMachine";
import { calculateRiskScore, getPortfolio } from "../lib/api";

export default function RiskSimulator() {
  const [portfolioValue,setPortfolioValue]=useState(""); const [equity,setEquity]=useState(""); const [debt,setDebt]=useState(""); const [others,setOthers]=useState("");
  const [portfolio,setPortfolio]=useState(null); const [loading,setLoading]=useState(false); const [error,setError]=useState("");
  const total=Number(equity||0)+Number(debt||0)+Number(others||0);
  const loadSavedPortfolio = async () => {
    try {
      const r = await getPortfolio();
      const saved = r.portfolio;
      const mix = saved.assetMix || [];
      setPortfolioValue(saved.value);
      setEquity(mix.find(a => a.label === "Equity")?.value ?? "");
      setDebt(mix.find(a => a.label === "Debt")?.value ?? "");
      setOthers(mix.find(a => a.label === "Others")?.value ?? "");
      setError("");
    } catch (e) {
      setError("No saved portfolio is available yet. Add one in Portfolio Overview first.");
    }
  };
  const assetMix=[{label:"Equity",value:Number(equity||0)},{label:"Debt",value:Number(debt||0)},{label:"Others",value:Number(others||0)}];
  const calculate=async()=>{setError(""); if(!Number(portfolioValue)||Number(portfolioValue)<=0){setError("Enter a portfolio value greater than zero.");return;} if(Math.abs(total-100)>.01){setError(`Allocation must total 100%. Current total: ${total}%.`);return;} try{setLoading(true);const r=await calculateRiskScore(assetMix);setPortfolio({value:Number(portfolioValue),riskScore:r.score,riskLabel:r.label,riskBreakdown:r.breakdown,riskFactors:r.factors,assetMix});}catch(e){setError(e.message||"Risk calculation failed.");}finally{setLoading(false)}};
  const clear=()=>{setPortfolioValue("");setEquity("");setDebt("");setOthers("");setPortfolio(null);setError("")};
  const input=(label,value,setValue,placeholder)=><label className="block"><span className="block text-xs font-semibold text-text-secondary mb-2">{label}</span><div className="relative"><input type="number" min="0" max="100" value={value} onChange={e=>setValue(e.target.value)} placeholder={placeholder} className="w-full bg-bg border border-border rounded-xl px-4 py-3.5 text-text-primary outline-none focus:border-accent"/><span className="absolute right-4 top-3.5 text-xs text-text-muted">%</span></div></label>;
  return <AppLayout><div className="max-w-5xl mx-auto px-6 py-10">
    <div className="flex items-start justify-between mb-8"><div className="flex gap-3"><div className="w-10 h-10 rounded-xl bg-accent-soft flex items-center justify-center"><Activity size={18} className="text-accent"/></div><div><p className="text-[0.65rem] font-bold tracking-[0.18em] text-text-muted">RISK ENGINE</p><h1 className="font-display text-2xl font-semibold text-text-primary mt-1">Risk Simulator</h1><p className="text-sm text-text-secondary mt-1">Model portfolio risk and replay historical stress scenarios.</p></div></div><button onClick={clear} className="text-xs font-semibold text-text-muted hover:text-text-primary inline-flex items-center gap-2"><RotateCcw size={14}/> Reset</button></div>
    <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-5 mb-6"><Card className="p-6"><div className="flex justify-between mb-6"><div><p className="text-[0.65rem] font-bold tracking-widest text-text-muted">PORTFOLIO INPUT</p><h2 className="font-display text-lg font-semibold text-text-primary mt-1">Use your actual allocation</h2></div><Badge tone="cyan">Live calculation</Badge></div>
      <label className="block mb-5"><span className="block text-xs font-semibold text-text-secondary mb-2">Portfolio value (₹)</span><input type="number" min="1" value={portfolioValue} onChange={e=>setPortfolioValue(e.target.value)} placeholder="Enter current value" className="w-full bg-bg border border-border rounded-xl px-4 py-3.5 text-text-primary outline-none focus:border-accent"/></label>
      <div className="grid sm:grid-cols-3 gap-3">{input("Equity",equity,setEquity,"0")}{input("Debt",debt,setDebt,"0")}{input("Others",others,setOthers,"0")}</div>
      <button type="button" onClick={loadSavedPortfolio} className="mt-4 text-xs font-semibold text-accent hover:text-accent/80">Use my saved Portfolio Overview allocation →</button>
      <div className="mt-5 p-4 rounded-xl border border-border bg-bg flex justify-between"><span className="text-sm text-text-secondary">Allocation total</span><span className={`font-semibold ${Math.abs(total-100)<.01?"text-positive":"text-danger"}`}>{total}%</span></div>
      {error&&<p className="mt-4 text-sm text-danger">{error}</p>}<button onClick={calculate} disabled={loading} className="w-full mt-5 rounded-xl bg-accent text-white font-semibold py-3.5 disabled:opacity-50">{loading?"Calculating...":"Calculate portfolio risk"}</button><Disclaimer className="mt-4"/>
    </Card><Card className="p-6"><div className="flex gap-3 items-start"><ShieldCheck className="text-positive mt-0.5" size={18}/><div><p className="font-semibold text-text-primary">Deterministic risk scoring</p><p className="text-sm text-text-secondary mt-1 leading-relaxed">The headline score is calculated by ClariFi's Python risk engine from the allocation you enter. The LLM does not invent the score.</p></div></div><div className="grid sm:grid-cols-3 gap-3 mt-6">{[["Volatility","Weighted asset risk"],["Drawdown","Equity downside exposure"],["Concentration","Allocation dominance"]].map(([a,b])=><div key={a} className="rounded-xl bg-white/[0.03] border border-border p-4"><p className="text-sm font-semibold text-text-primary">{a}</p><p className="text-xs text-text-muted mt-1">{b}</p></div>)}</div></Card></div>
    {portfolio&&<><div className="mb-6"><RiskScoreCard portfolio={portfolio}/></div><StressTestTimeMachine portfolio={portfolio}/></>}
  </div></AppLayout>
}
