import { Link } from "react-router-dom";
import Logo from "../components/Logo";

export default function AuthLayout({ children, side }) {
  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-bg">
      <div className="flex flex-col px-6 sm:px-12 py-8">
        <Link to="/">
          <Logo />
        </Link>
        <div className="flex-1 flex items-center justify-center py-10">
          <div className="w-full max-w-sm">{children}</div>
        </div>
      </div>
      <div className="hidden lg:flex flex-col justify-center bg-surface border-l border-border px-16 relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-accent/15 blur-3xl" />
        <div className="absolute -bottom-24 -left-16 w-80 h-80 rounded-full bg-accent-cyan/10 blur-3xl" />
        <div className="relative">
          <p className="font-display text-2xl font-semibold text-text-primary leading-snug mb-4">
            "{side.quote}"
          </p>
          <p className="text-text-secondary text-sm">{side.attribution}</p>
        </div>
      </div>
    </div>
  );
}
