import Sidebar from "../components/Sidebar";
import MobileNav from "../components/MobileNav";

export default function AppLayout({ children }) {
  return (
    <div className="flex min-h-screen w-full bg-[#050506] text-text-primary selection:bg-accent/30">
      <Sidebar />
      <div className="relative flex-1 min-w-0 pb-20 md:pb-0 overflow-hidden">
        <div className="pointer-events-none absolute -top-40 right-0 h-80 w-80 rounded-full bg-accent/[0.07] blur-3xl" />
        <div className="pointer-events-none absolute top-[38%] -left-40 h-72 w-72 rounded-full bg-accent/[0.035] blur-3xl" />
        <div className="relative">{children}</div>
      </div>
      <MobileNav />
    </div>
  );
}
