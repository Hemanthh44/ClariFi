import { NavLink } from "react-router-dom";
import { LayoutGrid, MessageCircle, Activity, ShieldAlert, Settings as SettingsIcon } from "lucide-react";

const navItems = [
  { to: "/dashboard", label: "Home", icon: LayoutGrid },
  { to: "/ask", label: "Ask", icon: MessageCircle },
  { to: "/risk-simulator", label: "Risk", icon: Activity },
  { to: "/scam-screener", label: "Scam", icon: ShieldAlert },
  { to: "/settings", label: "Settings", icon: SettingsIcon },
];

export default function MobileNav() {
  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 bg-[#050506]/95 backdrop-blur-xl border-t border-white/[0.07] shadow-[0_-12px_40px_-24px_rgba(225,29,46,0.45)] flex items-stretch justify-around px-1 pb-[env(safe-area-inset-bottom)] z-40">
      {navItems.map(({ to, label, icon: Icon }) => (
        <NavLink
          key={to}
          to={to}
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-0.5 py-2.5 flex-1 text-[0.65rem] font-medium ${
              isActive ? "text-accent" : "text-text-muted"
            }`
          }
        >
          <Icon size={19} strokeWidth={2} />
          {label}
        </NavLink>
      ))}
    </nav>
  );
}
