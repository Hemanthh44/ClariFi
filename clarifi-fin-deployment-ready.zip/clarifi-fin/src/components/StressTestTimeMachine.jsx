import { useEffect, useState } from "react";
import { ArrowDown, TrendingDown } from "lucide-react";
import { Card, Badge } from "./Basics";
import {
  getStressTestScenarios,
  runStressTest,
} from "../lib/api";

function formatINR(n) {
  return "₹" + Math.round(n).toLocaleString("en-IN");
}

export default function StressTestTimeMachine({ portfolio }) {
  const [scenarios, setScenarios] = useState([]);
  const [activeId, setActiveId] = useState("");
  const [result, setResult] = useState(null);

  const [loadingScenarios, setLoadingScenarios] = useState(true);
  const [loadingTest, setLoadingTest] = useState(false);
  const [error, setError] = useState("");

  /*
   * Get available historical scenarios from FastAPI.
   */
  useEffect(() => {
    async function loadScenarios() {
      try {
        setLoadingScenarios(true);

        const data = await getStressTestScenarios();

        setScenarios(data);

        if (data.length > 0) {
          setActiveId(data[0].id);
        }
      } catch (err) {
        console.error("Failed to load scenarios:", err);
        setError("Unable to load stress-test scenarios.");
      } finally {
        setLoadingScenarios(false);
      }
    }

    loadScenarios();
  }, []);


  /*
   * Run stress test whenever:
   * - portfolio changes
   * - selected scenario changes
   */
  useEffect(() => {
    if (!portfolio || !activeId) {
      return;
    }

    async function executeStressTest() {
      try {
        setLoadingTest(true);
        setError("");

        const data = await runStressTest(
          activeId,
          portfolio.value,
          portfolio.assetMix
        );

        setResult(data);
      } catch (err) {
        console.error("Stress test failed:", err);
        setError(
          err.message || "Unable to run stress test."
        );
      } finally {
        setLoadingTest(false);
      }
    }

    executeStressTest();
  }, [portfolio, activeId]);


  if (loadingScenarios) {
    return (
      <Card className="p-6">
        <p className="text-sm text-text-muted">
          Loading historical scenarios...
        </p>
      </Card>
    );
  }


  if (!portfolio) {
    return null;
  }


  return (
    <Card className="p-6 sm:p-8">

      {/* Header */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">

        <div>
          <p className="text-xs font-bold tracking-widest text-accent-cyan mb-1">
            STRESS-TEST TIME MACHINE
          </p>

          <h3 className="font-display text-xl font-semibold text-text-primary">
            See how your portfolio would have reacted
          </h3>
        </div>

        <Badge tone="cyan">
          Deterministic Risk Engine
        </Badge>

      </div>


      {/* Scenario selector */}
      <div className="flex flex-wrap gap-2 mb-8">

        {scenarios.map((scenario) => (
          <button
            key={scenario.id}
            onClick={() => setActiveId(scenario.id)}
            className={`px-4 py-2 rounded-xl text-sm font-semibold border transition-colors ${
              activeId === scenario.id
                ? "bg-accent-soft border-accent text-accent"
                : "border-border text-text-secondary hover:border-accent/40 hover:text-text-primary"
            }`}
          >
            {scenario.name}
          </button>
        ))}

      </div>


      {/* Error */}
      {error && (
        <div className="mb-6 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3">
          <p className="text-sm text-danger">
            {error}
          </p>
        </div>
      )}


      {/* Loading */}
      {loadingTest && (
        <div className="py-10 text-center">
          <p className="text-sm text-text-muted">
            Running deterministic stress test...
          </p>
        </div>
      )}


      {/* Result */}
      {!loadingTest && result && (
        <>

          {/* Timeline */}
          <div className="relative h-1 bg-white/5 rounded-full mb-10">

            <div
              className="absolute inset-y-0 left-0 bg-gradient-to-r from-accent to-danger rounded-full"
              style={{ width: "100%" }}
            />

            <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-bg border-2 border-danger" />

            <p className="absolute top-3 left-1/2 -translate-x-1/2 text-[0.65rem] text-text-muted whitespace-nowrap">
              {result.period}
            </p>

          </div>


          {/* Impact flow */}
          <div className="grid sm:grid-cols-[1fr,auto,1fr] items-center gap-4 mb-8">

            <div className="text-center sm:text-right">

              <p className="text-xs text-text-muted mb-1">
                YOUR PORTFOLIO
              </p>

              <p className="font-display text-2xl font-bold text-text-primary tabular">
                {formatINR(result.starting_value)}
              </p>

            </div>


            <div className="flex justify-center">

              <div className="flex flex-col items-center text-text-muted">

                <ArrowDown size={18} className="mb-1" />

                <span className="text-[0.65rem]">
                  Historical shock
                </span>

                <ArrowDown size={18} className="mt-1" />

              </div>

            </div>


            <div className="text-center sm:text-left">

              <p className="text-xs text-text-muted mb-1">
                ESTIMATED IMPACT
              </p>

              <p className="font-display text-2xl font-bold text-danger tabular">
                {formatINR(result.impact_value)}
              </p>

              <p className="text-sm font-semibold text-danger flex items-center gap-1 justify-center sm:justify-start mt-0.5">

                <TrendingDown size={14} />

                {result.impact_pct}%

              </p>

            </div>

          </div>


          {/* Narrative */}
          <p className="text-sm text-text-secondary leading-relaxed mb-6 bg-white/[0.03] rounded-xl p-4">
            {result.narrative}
          </p>


          {/* Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">

            {[
              {
                label: "Max drawdown",
                value: `${result.drawdown_pct}%`,
              },
              {
                label: "Recovery period",
                value: `${result.recovery_months} mo`,
              },
              {
                label: "Risk score change",
                value: `+${result.risk_score_change}`,
              },
              {
                label: "Period",
                value: result.period,
              },
            ].map((metric) => (

              <div
                key={metric.label}
                className="bg-white/[0.03] rounded-xl p-3.5"
              >

                <p className="text-[0.65rem] text-text-muted mb-1">
                  {metric.label}
                </p>

                <p className="font-display text-lg font-semibold text-text-primary tabular">
                  {metric.value}
                </p>

              </div>

            ))}

          </div>


          {/* Asset impact */}
          <p className="text-xs font-bold tracking-widest text-text-muted mb-3">
            ASSET-LEVEL IMPACT
          </p>

          <div className="space-y-2.5">

            {result.asset_impact.map((asset) => (

              <div
                key={asset.label}
                className="flex items-center gap-3"
              >

                <span className="text-sm text-text-secondary w-16 shrink-0">
                  {asset.label}
                </span>

                <div className="flex-1 h-2 rounded-full bg-white/5 overflow-hidden">

                  <div
                    className="h-full rounded-full bg-danger"
                    style={{
                      width: `${Math.min(
                        Math.abs(asset.impact_pct) * 2,
                        100
                      )}%`,
                    }}
                  />

                </div>

                <span className="text-sm font-semibold text-danger tabular w-14 text-right">
                  {asset.impact_pct}%
                </span>

              </div>

            ))}

          </div>

        </>

      )}

    </Card>
  );
}