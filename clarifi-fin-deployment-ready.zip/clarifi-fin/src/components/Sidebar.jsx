import { NavLink } from "react-router-dom";
import {
  LayoutGrid,
  MessageCircle,
  FileSearch,
  Activity,
  ShieldAlert,
  PieChart,
  Gauge,
  History as HistoryIcon,
  Library,
  Settings as SettingsIcon,
} from "lucide-react";
import Logo from "./Logo";
import { Avatar } from "./Basics";
const user = { name: "ClariFi User", email: "Local workspace", initials: "CF" };

const groups = [
  {
    label: null,
    items: [{ to: "/dashboard", label: "Overview", icon: LayoutGrid }],
  },
  {
    label: "AI Co-Pilot",
    items: [
      { to: "/ask", label: "Ask ClariFi", icon: MessageCircle },
      { to: "/product-explainer", label: "Product Explainer", icon: FileSearch },
      { to: "/risk-simulator", label: "Risk Simulator", icon: Activity },
      { to: "/scam-screener", label: "Scam Screener", icon: ShieldAlert },
    ],
  },
  {
    label: "Portfolio",
    items: [
      { to: "/portfolio", label: "Portfolio Overview", icon: PieChart },
      { to: "/risk-simulator", label: "Risk Profile", icon: Gauge },
    ],
  },
  {
    label: "Knowledge",
    items: [
      { to: "/documents", label: "Documents", icon: Library },
      { to: "/history", label: "History", icon: HistoryIcon },
    ],
  },
];

export default function Sidebar() {
  return (
    <aside className="hidden md:flex flex-col w-64 shrink-0 border-r border-white/[0.07] bg-[#050506]/95 backdrop-blur-xl h-screen sticky top-0 py-5 px-3.5 overflow-y-auto no-scrollbar">
      <div className="px-2 mb-7">
        <Logo />
      </div>
      <nav className="flex flex-col gap-5 flex-1">
        {groups.map((group, gi) => (
          <div key={gi}>
            {group.label && (
              <p className="px-3 mb-1.5 text-[0.65rem] font-bold tracking-widest text-text-muted">
                {group.label.toUpperCase()}
              </p>
            )}
            <div className="flex flex-col gap-0.5">
              {group.items.map(({ to, label, icon: Icon }) => (
                <NavLink
                  key={label}
                  to={to}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3 py-2.25 rounded-xl text-sm font-medium transition-colors ${
                      isActive
                        ? "bg-accent/[0.11] text-accent border border-accent/15 shadow-[inset_3px_0_0_#F0203A]"
                        : "text-text-secondary hover:bg-white/[0.04] hover:text-text-primary"
                    }`
                  }
                >
                  <Icon size={16} strokeWidth={2} />
                  {label}
                </NavLink>
              ))}
            </div>
          </div>
        ))}
      </nav>
      <NavLink
        to="/settings"
        className="flex items-center gap-2.5 px-2 py-2 rounded-xl hover:bg-white/5 transition-colors mt-4 border-t border-border pt-4"
      >
        <Avatar initials={user.initials} size={32} />
        <div className="min-w-0">
          <p className="text-sm font-medium text-text-primary truncate">{user.name}</p>
          <p className="text-xs text-text-muted truncate">{user.email}</p>
        </div>
        <SettingsIcon size={15} className="ml-auto text-text-muted shrink-0" />
      </NavLink>
    </aside>
  );
}
