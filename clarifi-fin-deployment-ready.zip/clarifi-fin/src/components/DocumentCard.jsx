import { FileText, CheckCircle2, MoreVertical, MessageSquare, MoreHorizontal } from "lucide-react";
import { Card, Badge } from "./Basics";

export function DocumentCard({ doc }) {
  return (
    <Card hover className="p-5 relative group">
      <div className="flex items-start justify-between mb-4">
        <div className="w-10 h-10 rounded-lg bg-accent-soft flex items-center justify-center">
          <FileText size={18} className="text-accent" />
        </div>
        <button className="p-1.5 rounded-lg text-text-muted hover:text-text-primary hover:bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="More">
          <MoreVertical size={16} />
        </button>
      </div>
      <Badge tone="neutral" className="mb-2">{doc.category}</Badge>
      <h3 className="font-medium text-text-primary text-[0.95rem] mb-2 truncate">{doc.name}</h3>
      <div className="flex items-center gap-2 text-xs text-text-muted mb-3">
        <span>{doc.pages} pages</span>
        <span className="w-1 h-1 rounded-full bg-text-muted" />
        <span>Added {doc.addedDaysAgo}d ago</span>
      </div>
      {doc.indexed && (
        <div className="flex items-center gap-1.5 text-xs font-semibold text-positive">
          <CheckCircle2 size={13} /> RAG Indexed
        </div>
      )}
    </Card>
  );
}

export function HistoryItem({ item }) {
  return (
    <a href="#" onClick={(e) => e.preventDefault()} className="group flex items-start gap-3 px-3.5 py-3 rounded-xl hover:bg-white/5 transition-colors">
      <div className="w-8 h-8 rounded-lg bg-accent-soft flex items-center justify-center shrink-0 mt-0.5">
        <MessageSquare size={14} className="text-accent" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-text-primary truncate">{item.title}</p>
        <p className="text-xs text-text-muted truncate mt-0.5">{item.preview}</p>
        <p className="text-[0.7rem] text-text-muted/70 mt-1">{item.date}</p>
      </div>
      <button onClick={(e) => e.preventDefault()} className="p-1 rounded-md text-text-muted hover:text-text-primary opacity-0 group-hover:opacity-100 transition-opacity" aria-label="More">
        <MoreHorizontal size={16} />
      </button>
    </a>
  );
}
