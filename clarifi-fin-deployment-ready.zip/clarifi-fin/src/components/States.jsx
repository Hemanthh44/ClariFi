export function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center text-center py-16 px-6">
      {Icon && (
        <div className="w-14 h-14 rounded-2xl bg-accent-soft flex items-center justify-center mb-5">
          <Icon size={24} className="text-accent" strokeWidth={1.8} />
        </div>
      )}
      <h3 className="font-display text-xl text-text-primary mb-1.5">{title}</h3>
      <p className="text-text-secondary text-sm max-w-sm mb-6">{description}</p>
      {action}
    </div>
  );
}

const stages = ["Selecting specialist...", "Retrieving evidence...", "Running analysis...", "Checking compliance..."];

export function LoadingState({ stage = 0 }) {
  return (
    <div className="flex items-center gap-3 text-text-secondary text-sm py-3">
      <span className="flex gap-1">
        <span className="w-1.5 h-1.5 rounded-full bg-accent animate-bounce [animation-delay:-0.3s]" />
        <span className="w-1.5 h-1.5 rounded-full bg-accent animate-bounce [animation-delay:-0.15s]" />
        <span className="w-1.5 h-1.5 rounded-full bg-accent animate-bounce" />
      </span>
      <span>{stages[stage] ?? stages[0]}</span>
    </div>
  );
}
