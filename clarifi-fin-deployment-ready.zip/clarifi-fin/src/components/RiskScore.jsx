import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { Card } from "./Basics";

const toneForScore = (score) => {
  if (score < 34) return { color: "#34D399", label: "Low" };
  if (score < 67) return { color: "#F59E0B", label: "Moderate" };
  return { color: "#F87171", label: "High" };
};

export function RiskOrb({ score, size = 140 }) {
  const { color } = toneForScore(score);
  const circumference = 2 * Math.PI * 54;
  const offset = circumference - (score / 100) * circumference;

  return (
    <svg width={size} height={size} viewBox="0 0 140 140" className="shrink-0">
      <circle cx="70" cy="70" r="54" fill="none" stroke="#242A34" strokeWidth="10" />
      <circle
        cx="70"
        cy="70"
        r="54"
        fill="none"
        stroke={color}
        strokeWidth="10"
        strokeLinecap="round"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        transform="rotate(-90 70 70)"
        style={{ transition: "stroke-dashoffset 0.6s ease" }}
      />
      <text x="70" y="68" textAnchor="middle" fill="#F4F5F7" fontSize="30" fontWeight="700" fontFamily="Space Grotesk, sans-serif">
        {score}
      </text>
      <text x="70" y="86" textAnchor="middle" fill="#687180" fontSize="9" fontWeight="700" letterSpacing="1">
        / 100
      </text>
    </svg>
  );
}

export function RiskBar({ label, value }) {
  const { color } = toneForScore(value);
  return (
    <div className="mb-3 last:mb-0">
      <div className="flex justify-between text-xs mb-1.5">
        <span className="text-text-secondary">{label}</span>
        <span className="text-text-primary font-semibold tabular">{value}%</span>
      </div>
      <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
        <div className="h-full rounded-full" style={{ width: `${value}%`, backgroundColor: color }} />
      </div>
    </div>
  );
}

export function RiskScoreCard({ portfolio }) {
  const [expanded, setExpanded] = useState(false);
  const { label } = toneForScore(portfolio.riskScore);

  return (
    <Card className="p-6">
      <p className="text-xs font-bold tracking-widest text-text-muted mb-4">RISK SCORE</p>
      <div className="flex items-center gap-6 mb-5">
        <RiskOrb score={portfolio.riskScore} />
        <div>
          <p className="font-display text-xl font-semibold text-text-primary mb-1">{label}</p>
          <p className="text-sm text-text-secondary">Based on your current allocation and market history.</p>
        </div>
      </div>
      <div className="mb-2">
        {portfolio.riskBreakdown.map((r) => (
          <RiskBar key={r.label} label={r.label} value={r.value} />
        ))}
      </div>
      <button
        onClick={() => setExpanded((e) => !e)}
        className="w-full flex items-center justify-between text-sm font-semibold text-accent hover:text-accent/80 mt-4 pt-4 border-t border-border transition-colors"
      >
        Why this score?
        <ChevronDown size={16} className={`transition-transform ${expanded ? "rotate-180" : ""}`} />
      </button>
      {expanded && (
        <div className="mt-4 bg-white/[0.03] rounded-xl p-4 animate-rise">
          <p className="text-xs font-bold tracking-widest text-text-muted mb-3">WHY THIS SCORE?</p>
          <ul className="space-y-2 mb-4">
            {portfolio.riskFactors.map((f, i) => (
              <li key={i} className="flex gap-2 text-sm text-text-secondary leading-relaxed">
                <span className="w-1 h-1 rounded-full bg-accent mt-2 shrink-0" />
                {f}
              </li>
            ))}
          </ul>
          <p className="text-[0.7rem] text-text-muted">Calculated by ClariFi Risk Engine</p>
        </div>
      )}
    </Card>
  );
}
