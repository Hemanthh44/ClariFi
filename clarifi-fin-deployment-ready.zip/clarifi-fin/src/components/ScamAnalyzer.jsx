import { useState } from "react";
import { AlertTriangle, ChevronDown } from "lucide-react";
import { Card, Badge } from "./Basics";

export function HighlightedMessage({ message, flags }) {
  // Build segments by splitting on flagged spans
  let remaining = message;
  const segments = [];
  const sorted = [...flags].sort((a, b) => message.indexOf(a.span) - message.indexOf(b.span));

  let cursor = 0;
  sorted.forEach((f) => {
    const idx = message.indexOf(f.span, cursor);
    if (idx === -1) return;
    if (idx > cursor) segments.push({ text: message.slice(cursor, idx), flagged: false });
    segments.push({ text: f.span, flagged: true, label: f.label });
    cursor = idx + f.span.length;
  });
  if (cursor < message.length) segments.push({ text: message.slice(cursor), flagged: false });

  return (
    <p className="text-sm text-text-secondary leading-relaxed">
      {segments.map((seg, i) =>
        seg.flagged ? (
          <mark key={i} className="bg-danger/15 text-danger rounded px-0.5 font-medium not-italic">
            {seg.text}
          </mark>
        ) : (
          <span key={i}>{seg.text}</span>
        )
      )}
    </p>
  );
}

export function RiskLevelBanner({ level }) {
  const tone = level.includes("High") ? "danger" : level.includes("Suspicious") ? "warning" : "positive";
  return (
    <div
      className={`flex items-center gap-3 rounded-xl p-4 ${
        tone === "danger" ? "bg-danger/10" : tone === "warning" ? "bg-warning/10" : "bg-positive/10"
      }`}
    >
      <AlertTriangle size={20} className={tone === "danger" ? "text-danger" : tone === "warning" ? "text-warning" : "text-positive"} />
      <div>
        <p className="text-[0.65rem] font-bold tracking-widest text-text-muted">RISK LEVEL</p>
        <p className={`font-display text-lg font-bold ${tone === "danger" ? "text-danger" : tone === "warning" ? "text-warning" : "text-positive"}`}>
          {level.toUpperCase()}
        </p>
      </div>
    </div>
  );
}

export function RedFlagList({ flags }) {
  return (
    <div>
      <p className="text-[0.65rem] font-bold tracking-widest text-text-muted mb-2">RED FLAGS DETECTED</p>
      <ul className="space-y-2">
        {flags.map((f, i) => (
          <li key={i} className="flex gap-2.5 text-sm text-text-primary items-start">
            <span className="text-danger font-display font-semibold text-xs shrink-0 mt-0.5">
              {String(i + 1).padStart(2, "0")}
            </span>
            {f.label}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function ExplainabilityDrawer({ title, children }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-t border-border pt-3 mt-4">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center justify-between w-full text-sm font-semibold text-accent hover:text-accent/80 transition-colors"
      >
        {title}
        <ChevronDown size={16} className={`transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && <div className="mt-3 animate-rise">{children}</div>}
    </div>
  );
}
