export default function Logo({ size = 28, withWordmark = true, className = "" }) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <path
          d="M28 11.5C25.8 9.3 22.9 8 19.7 8C13.2 8 8 13.4 8 20C8 26.6 13.2 32 19.7 32C22.9 32 25.8 30.7 28 28.5"
          stroke="#F0203A"
          strokeWidth="3"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M14 22L18.5 17L22.5 20.5L29 13"
          stroke="#FF7A84"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        <circle cx="29" cy="13" r="2.4" fill="#FF7A84" />
      </svg>
      {withWordmark && (
        <span className="font-display font-semibold text-[1.15rem] tracking-tight text-text-primary">
          Clari<span className="text-accent">Fi</span>
        </span>
      )}
    </div>
  );
}
