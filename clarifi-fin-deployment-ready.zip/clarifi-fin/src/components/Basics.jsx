import { ShieldCheck } from "lucide-react";

export function Card({ children, className = "", hover = false, as: Component = "div", ...props }) {
  return (
    <Component
      className={`bg-surface/95 backdrop-blur-xl border border-white/[0.07] rounded-xl2 shadow-panel ring-1 ring-black/20 ${
        hover ? "transition-all duration-200 hover:border-accent/50 hover:-translate-y-0.5 hover:shadow-glow" : ""
      } ${className}`}
      {...props}
    >
      {children}
    </Component>
  );
}

export function Badge({ children, tone = "neutral", className = "" }) {
  const tones = {
    neutral: "bg-white/5 text-text-secondary",
    accent: "bg-accent-soft text-accent",
    cyan: "bg-accent-cyanSoft text-accent-cyan",
    positive: "bg-positive/10 text-positive",
    warning: "bg-warning/10 text-warning",
    danger: "bg-danger/10 text-danger",
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${tones[tone]} ${className}`}>
      {children}
    </span>
  );
}

export function Avatar({ initials = "?", size = 36, className = "" }) {
  return (
    <div
      className={`flex items-center justify-center rounded-full bg-accent text-white font-semibold shrink-0 ${className}`}
      style={{ width: size, height: size, fontSize: size * 0.36 }}
    >
      {initials}
    </div>
  );
}

export function ComplianceBadge({ className = "" }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-positive/10 text-positive ${className}`}
    >
      <ShieldCheck size={13} /> Compliance Checked
    </span>
  );
}

export function Disclaimer({ className = "" }) {
  return (
    <p className={`text-[0.7rem] text-text-muted leading-relaxed ${className}`}>
      ClariFi provides educational and analytical information. It does not provide personalized investment advice or
      explicit buy/sell recommendations.
    </p>
  );
}
