import { useState } from "react";
const agents = [
  { id:"product-explainer", name:"Product Explainer", tagline:"Decode the fine print.", body:"Upload financial documents and ask questions in plain English.", example:"Ask about fees, exclusions, risks, or terms." },
  { id:"risk-simulator", name:"Risk Simulator", tagline:"Model portfolio stress.", body:"Calculate allocation risk and replay historical stress scenarios.", example:"Test your allocation against historical shocks." },
  { id:"summary-agent", name:"Summary Agent", tagline:"See your financial picture.", body:"Generate a concise analytical snapshot from your saved portfolio.", example:"Summarize my portfolio." },
  { id:"scam-screener", name:"Scam Screener", tagline:"Spot financial red flags.", body:"Analyze suspicious messages against known fraud patterns.", example:"Check this investment message." },
];

// Layout: orchestrator center, 4 agents around it
const positions = [
  { x: 200, y: 55 },   // top - Product Explainer
  { x: 345, y: 200 },  // right - Risk Simulator
  { x: 200, y: 345 },  // bottom - Summary Agent
  { x: 55, y: 200 },   // left - Scam Screener
];

export default function AgentNetwork({ compact = false }) {
  const [active, setActive] = useState(null);
  const size = compact ? 320 : 400;

  return (
    <div className="relative" style={{ width: "100%", maxWidth: size }}>
      <svg viewBox="0 0 400 400" className="w-full h-auto" role="img" aria-label="ClariFi multi-agent network">
        {/* connecting lines */}
        {positions.map((p, i) => (
          <line
            key={i}
            x1="200"
            y1="200"
            x2={p.x}
            y2={p.y}
            stroke={active === i ? "#F0203A" : "#242A34"}
            strokeWidth={active === i ? 2 : 1.4}
            className={active === i ? "animate-pulseLine" : ""}
          />
        ))}

        {/* orchestrator core */}
        <circle cx="200" cy="200" r="46" fill="#151A22" stroke="#F0203A" strokeWidth="1.5" />
        <circle cx="200" cy="200" r="46" fill="url(#coreGlow)" opacity="0.5" />
        <defs>
          <radialGradient id="coreGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#F0203A" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#F0203A" stopOpacity="0" />
          </radialGradient>
        </defs>
        <text x="200" y="196" textAnchor="middle" fill="#F4F5F7" fontSize="11" fontWeight="700" fontFamily="Space Grotesk, sans-serif">
          CLARIFI
        </text>
        <text x="200" y="210" textAnchor="middle" fill="#A3AAB8" fontSize="8" fontWeight="600" letterSpacing="0.5">
          ORCHESTRATOR
        </text>

        {/* agent nodes */}
        {agents.map((agent, i) => {
          const p = positions[i];
          const isActive = active === i;
          return (
            <g
              key={agent.id}
              className="cursor-pointer animate-floatNode"
              style={{ animationDelay: `${i * 0.4}s` }}
              onMouseEnter={() => setActive(i)}
              onMouseLeave={() => setActive(null)}
              onClick={() => setActive(isActive ? null : i)}
            >
              <circle
                cx={p.x}
                cy={p.y}
                r={isActive ? 34 : 30}
                fill={isActive ? "#2A0B11" : "#10141B"}
                stroke={isActive ? "#F0203A" : "#242A34"}
                strokeWidth={isActive ? 2 : 1.2}
                className="transition-all duration-200"
              />
              <text
                x={p.x}
                y={p.y - 3}
                textAnchor="middle"
                fill={isActive ? "#FF7A84" : "#A3AAB8"}
                fontSize="7.5"
                fontWeight="700"
                fontFamily="Manrope, sans-serif"
              >
                {agent.name.split(" ")[0].toUpperCase()}
              </text>
              <text
                x={p.x}
                y={p.y + 8}
                textAnchor="middle"
                fill={isActive ? "#FF7A84" : "#687180"}
                fontSize="7.5"
                fontWeight="700"
                fontFamily="Manrope, sans-serif"
              >
                {agent.name.split(" ")[1]?.toUpperCase() ?? ""}
              </text>
            </g>
          );
        })}
      </svg>

      {active !== null && (
        <div className="mt-2 bg-surface-elevated border border-border rounded-xl p-4 animate-rise">
          <p className="font-display font-semibold text-sm text-text-primary mb-1">{agents[active].name}</p>
          <p className="text-xs text-text-secondary mb-2">{agents[active].body}</p>
          <p className="text-xs text-accent-cyan mb-1">{agents[active].example}</p>
          <p className="text-[0.65rem] text-text-muted">{agents[active].source}</p>
        </div>
      )}
    </div>
  );
}
