import { useState } from "react";
import { Sparkles, ChevronDown, FileText, CheckCircle2 } from "lucide-react";
import { Card, ComplianceBadge } from "./Basics";

export function SourceCard({ source }) {
  const isWeb = source.source_type === "web" && source.url;

  const content = (
    <>
      <div className="flex items-center gap-2 mb-0.5">
        <FileText size={12} className="text-accent-cyan shrink-0" />
        <span className="text-sm font-medium text-text-primary truncate">
          {source.doc}
        </span>
      </div>
      <p className="text-xs text-text-muted pl-5 truncate">
        {isWeb
          ? source.domain || "Web source"
          : `Page ${source.page}${source.section ? ` · ${source.section}` : ""}`}
      </p>
    </>
  );

  if (isWeb) {
    return (
      <a
        href={source.url}
        target="_blank"
        rel="noreferrer"
        className="block p-3 rounded-xl border border-border bg-white/[0.03] hover:border-accent/40 transition-colors"
      >
        {content}
      </a>
    );
  }

  return (
    <div className="block p-3 rounded-xl border border-border bg-white/[0.03]">
      {content}
    </div>
  );
}

export function UserBubble({ text }) {
  return (
    <div className="flex justify-end">
      <div className="max-w-[80%] bg-accent text-white rounded-2xl rounded-tr-md px-4 py-2.5 text-[0.95rem]">
        {text}
      </div>
    </div>
  );
}

export function RetrievalTrail({ steps }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-t border-border pt-3 mt-3">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1.5 text-xs font-semibold text-text-secondary hover:text-accent-cyan transition-colors"
      >
        Sources & retrieval
        <ChevronDown size={13} className={`transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="mt-3 flex flex-wrap items-center gap-1.5 animate-rise">
          {steps.map((s, i) => (
            <div key={s} className="flex items-center gap-1.5">
              <span className="text-[0.65rem] px-2.5 py-1 rounded-full bg-white/5 text-text-secondary">{s}</span>
              {i < steps.length - 1 && <span className="text-text-muted text-xs">→</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function AnswerMessage({ data }) {
  return (
    <div className="flex gap-3 max-w-[92%]">
      <div className="w-7 h-7 rounded-full bg-accent flex items-center justify-center shrink-0 mt-1">
        <Sparkles size={13} className="text-white" />
      </div>
      <Card className="p-5 flex-1">
        <div className="flex items-center justify-between mb-3">
          <p className="text-[0.65rem] font-bold tracking-widest text-accent">ANSWER</p>
          <ComplianceBadge />
        </div>
        <p className="text-[0.95rem] text-text-primary leading-relaxed mb-4">{data.answer}</p>

        <p className="text-[0.65rem] font-bold tracking-widest text-text-muted mb-2">KEY TAKEAWAYS</p>
        <ul className="space-y-1.5 mb-4">
          {data.keyTakeaways.map((point, i) => (
            <li key={i} className="flex gap-2.5 text-sm text-text-secondary leading-relaxed">
              <span className="text-accent-cyan font-display font-semibold text-xs shrink-0 mt-0.5">
                {String(i + 1).padStart(2, "0")}
              </span>
              {point}
            </li>
          ))}
        </ul>

        <p className="text-[0.65rem] font-bold tracking-widest text-text-muted mb-2">SOURCES</p>
        <div className="grid sm:grid-cols-2 gap-2">
          {data.sources.map((s, i) => (
            <SourceCard key={i} source={s} />
          ))}
        </div>

        {data.retrievalTrail && <RetrievalTrail steps={data.retrievalTrail} />}
      </Card>
    </div>
  );
}

const activitySteps = [
  "Query understood",
  "Product Explainer consulted",
  "RAG retrieval completed",
  "Risk Engine calculated",
  "Compliance check passed",
];

export function AgentActivityPanel({ done = true }) {
  return (
    <Card className="p-4">
      <p className="text-[0.65rem] font-bold tracking-widest text-text-muted mb-3">CLARIFI AGENTS</p>
      <div className="space-y-2">
        {activitySteps.map((step, i) => (
          <div key={step} className="flex items-center gap-2 text-sm">
            <CheckCircle2 size={14} className={done ? "text-positive" : "text-text-muted"} />
            <span className={done ? "text-text-secondary" : "text-text-muted"}>{step}</span>
          </div>
        ))}
      </div>
      {done && <p className="text-xs font-semibold text-positive mt-3 pt-3 border-t border-border">Response ready</p>}
    </Card>
  );
}
