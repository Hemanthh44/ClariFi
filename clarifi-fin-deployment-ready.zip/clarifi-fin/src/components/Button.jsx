const variants = {
  primary: "bg-accent text-white hover:bg-accent/90 shadow-glow hover:shadow-[0_12px_36px_-12px_rgba(240,32,58,0.65)]",
  secondary: "bg-surface-elevated text-text-primary border border-white/[0.08] hover:border-accent/50 hover:bg-accent/[0.04]",
  ghost: "text-text-secondary hover:text-text-primary hover:bg-white/5",
  cyan: "bg-accent-cyan text-bg hover:bg-accent-cyan/90",
};

const sizes = {
  sm: "text-sm px-3.5 py-1.5 rounded-lg gap-1.5",
  md: "text-[0.95rem] px-5 py-2.5 rounded-xl gap-2",
  lg: "text-base px-7 py-3.5 rounded-xl gap-2.5",
};

export default function Button({
  children,
  variant = "primary",
  size = "md",
  className = "",
  icon: Icon,
  iconPosition = "left",
  as: Component = "button",
  ...props
}) {
  return (
    <Component
      className={`inline-flex items-center justify-center font-semibold transition-all duration-150 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {Icon && iconPosition === "left" && <Icon size={size === "lg" ? 19 : 16} strokeWidth={2.2} />}
      {children}
      {Icon && iconPosition === "right" && <Icon size={size === "lg" ? 19 : 16} strokeWidth={2.2} />}
    </Component>
  );
}
