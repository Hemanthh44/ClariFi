import { Search } from "lucide-react";

export function Input({ label, className = "", id, ...props }) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={id} className="text-sm font-medium text-text-secondary">
          {label}
        </label>
      )}
      <input
        id={id}
        className={`px-4 py-2.75 rounded-xl border border-border bg-surface text-text-primary placeholder:text-text-muted focus:border-accent transition-colors outline-none ${className}`}
        {...props}
      />
    </div>
  );
}

export function SearchBar({ placeholder = "Search...", value, onChange, className = "" }) {
  return (
    <div className={`relative ${className}`}>
      <Search size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
      <input
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-border bg-surface text-sm text-text-primary placeholder:text-text-muted focus:border-accent transition-colors outline-none"
      />
    </div>
  );
}
