import { Card } from "./Basics";

export function StatCard({ label, value, sub, accent = false }) {
  return (
    <Card className="p-5">
      <p className="text-[0.65rem] font-bold tracking-widest text-text-muted mb-2">{label}</p>
      <p className={`font-display text-2xl font-bold tabular ${accent ? "text-accent-cyan" : "text-text-primary"}`}>
        {value}
      </p>
      {sub && <p className="text-xs text-text-secondary mt-1">{sub}</p>}
    </Card>
  );
}

export function AssetMixCard({ assetMix }) {
  return (
    <Card className="p-5">
      <p className="text-[0.65rem] font-bold tracking-widest text-text-muted mb-3">ASSET MIX</p>
      <div className="flex h-2.5 rounded-full overflow-hidden mb-4">
        {assetMix.map((a) => (
          <div key={a.label} style={{ width: `${a.value}%`, backgroundColor: a.color }} />
        ))}
      </div>
      <div className="space-y-2">
        {assetMix.map((a) => (
          <div key={a.label} className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2 text-text-secondary">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: a.color }} />
              {a.label}
            </span>
            <span className="font-semibold text-text-primary tabular">{a.value}%</span>
          </div>
        ))}
      </div>
    </Card>
  );
}
