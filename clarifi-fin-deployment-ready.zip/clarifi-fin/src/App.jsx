import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import Ask from "./pages/Ask";
import ProductExplainer from "./pages/ProductExplainer";
import RiskSimulator from "./pages/RiskSimulator";
import ScamScreener from "./pages/ScamScreener";
import Documents from "./pages/Documents";
import Portfolio from "./pages/Portfolio";
import History from "./pages/History";
import Settings from "./pages/Settings";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/ask" element={<Ask />} />
        <Route path="/product-explainer" element={<ProductExplainer />} />
        <Route path="/risk-simulator" element={<RiskSimulator />} />
        <Route path="/scam-screener" element={<ScamScreener />} />
        <Route path="/documents" element={<Documents />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/history" element={<History />} />
        <Route path="/settings" element={<Settings />} />
      </Routes>
    </BrowserRouter>
  );
}
