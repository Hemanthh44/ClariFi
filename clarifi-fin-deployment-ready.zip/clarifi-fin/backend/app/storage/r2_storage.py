"""Cloudflare R2 object storage for uploaded documents (S3-compatible API).

Nothing here touches the local filesystem for persistence — uploaded PDFs
live in R2, and only their metadata + `object_key` are stored in
PostgreSQL (see app/db/models.py: Document). That split is what lets
documents survive a Render redeploy, where local disk is ephemeral.

Every function raises `StorageError` on failure instead of letting a raw
boto3/botocore exception (which can include request internals) bubble up
to a router; routers turn `StorageError` into a clean HTTP error.
"""
from __future__ import annotations

import logging
from pathlib import PurePosixPath

import boto3
from botocore.client import Config
from botocore.exceptions import BotoCoreError, ClientError

from app.config import get_settings

logger = logging.getLogger("clarifi.storage")


class StorageError(RuntimeError):
    """Raised for any R2/object-storage failure: missing config, network
    error, auth failure, or a missing object. Safe to show to the user —
    never wraps raw credentials or internal request details."""


def is_configured() -> bool:
    settings = get_settings()
    return bool(
        settings.r2_endpoint_url
        and settings.r2_access_key_id
        and settings.r2_secret_access_key
        and settings.r2_bucket_name
    )


def _client():
    if not is_configured():
        raise StorageError(
            "Object storage is not configured on this server (missing R2_* environment variables)."
        )
    settings = get_settings()
    return boto3.client(
        "s3",
        endpoint_url=settings.r2_endpoint_url,
        aws_access_key_id=settings.r2_access_key_id,
        aws_secret_access_key=settings.r2_secret_access_key,
        config=Config(signature_version="s3v4"),
        region_name="auto",
    )


def build_object_key(document_id: str, filename: str) -> str:
    """documents/{document_id}/{safe_filename}.

    `document_id` is always a server-generated UUID and the filename is
    reduced to its final path segment, so this can never be steered into a
    path-traversal key by user input.
    """
    safe_name = PurePosixPath(filename).name.replace("/", "_").replace("\\", "_").strip()
    safe_name = safe_name or "document"
    return f"documents/{document_id}/{safe_name}"


def upload_bytes(object_key: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    settings = get_settings()
    try:
        _client().put_object(Bucket=settings.r2_bucket_name, Key=object_key, Body=data, ContentType=content_type)
    except (BotoCoreError, ClientError) as exc:
        logger.warning("R2 upload failed for %s: %s", object_key, exc)
        raise StorageError("Could not upload the file to object storage. Please try again.") from exc


def download_bytes(object_key: str) -> bytes:
    settings = get_settings()
    try:
        obj = _client().get_object(Bucket=settings.r2_bucket_name, Key=object_key)
        return obj["Body"].read()
    except (BotoCoreError, ClientError) as exc:
        logger.warning("R2 download failed for %s: %s", object_key, exc)
        raise StorageError("Could not read the file from object storage.") from exc


def delete_object(object_key: str) -> None:
    settings = get_settings()
    try:
        _client().delete_object(Bucket=settings.r2_bucket_name, Key=object_key)
    except (BotoCoreError, ClientError) as exc:
        logger.warning("R2 delete failed for %s: %s", object_key, exc)
        raise StorageError("Could not delete the file from object storage.") from exc


def object_exists(object_key: str) -> bool:
    settings = get_settings()
    try:
        _client().head_object(Bucket=settings.r2_bucket_name, Key=object_key)
        return True
    except ClientError as exc:
        error_code = str(exc.response.get("Error", {}).get("Code", ""))
        if error_code in {"404", "NoSuchKey", "NotFound"}:
            return False
        logger.warning("R2 existence check failed for %s: %s", object_key, exc)
        raise StorageError("Could not check object storage.") from exc
    except BotoCoreError as exc:
        logger.warning("R2 existence check failed for %s: %s", object_key, exc)
        raise StorageError("Could not check object storage.") from exc


def public_url(object_key: str) -> str | None:
    """Best-effort public URL for a stored object, if the bucket/domain is
    public and R2_PUBLIC_BASE_URL is configured. Returns None otherwise —
    callers should not assume every object has a public URL."""
    settings = get_settings()
    if not settings.r2_public_base_url:
        return None
    return f"{settings.r2_public_base_url.rstrip('/')}/{object_key}"
