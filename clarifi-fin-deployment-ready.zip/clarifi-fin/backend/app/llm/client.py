"""Gemini-backed LLM client for ClariFi.

The LLM is used for intent classification, grounded document answers, web-grounded
answers, and plain-language narration around deterministic financial calculations.
The LLM never computes risk, stress-test, or fraud scores.

If GEMINI_API_KEY is not set (or the Gemini SDK cannot be initialized), the client
falls back to the existing deterministic/template behavior so the backend remains
runnable without an API key.
"""
from __future__ import annotations

import json
import logging
from typing import Optional

from app.config import get_settings

logger = logging.getLogger("clarifi.llm")


class LLMClient:
    def __init__(self) -> None:
        settings = get_settings()
        self.model = settings.llm_model
        self.template_mode = not bool(settings.gemini_api_key)
        self._client = None

        if not self.template_mode:
            try:
                from google import genai

                self._client = genai.Client(api_key=settings.gemini_api_key)
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning("Falling back to template mode: %s", exc)
                self.template_mode = True

    def _generate(
        self,
        *,
        system: str,
        contents: str,
        max_output_tokens: int,
        json_output: bool = False,
    ) -> str:
        """Generate text using the current Gemini model."""
        from google.genai import types

        config_kwargs = {
            "system_instruction": system,
            "max_output_tokens": max_output_tokens,
        }
        if json_output:
            config_kwargs["response_mime_type"] = "application/json"

        response = self._client.models.generate_content(
            model=self.model,
            contents=contents,
            config=types.GenerateContentConfig(**config_kwargs),
        )
        return (response.text or "").strip()

    @staticmethod
    def _parse_json(text: str) -> dict:
        """Parse Gemini JSON, tolerating accidental markdown fences."""
        cleaned = text.strip()
        if cleaned.startswith("```"):
            lines = cleaned.splitlines()
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            cleaned = "\n".join(lines).strip()
        return json.loads(cleaned)

    # -- Intent classification (Orchestrator routing) -------------------

    def classify_intent(self, message: str) -> str:
        """Return one of the four specialist agent labels."""
        if self.template_mode:
            return self._classify_intent_rule_based(message)

        system = (
            "You are ClariFi's Orchestrator Agent. Classify the user's request "
            "into exactly one specialist: product_explainer, risk_simulator, "
            "summary_agent, or scam_screener. Reply with only the label."
        )
        try:
            label = self._generate(
                system=system,
                contents=message,
                max_output_tokens=20,
            ).strip().lower()
            if label in {"product_explainer", "risk_simulator", "summary_agent", "scam_screener"}:
                return label
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("Gemini classify_intent failed, using rules: %s", exc)
        return self._classify_intent_rule_based(message)

    @staticmethod
    def _classify_intent_rule_based(message: str) -> str:
        text = message.lower()
        if any(w in text for w in ["scam", "fraud", "whatsapp", "telegram", "suspicious", "guaranteed return"]):
            return "scam_screener"
        if any(w in text for w in ["stress test", "crash", "2008", "2020", "2013", "risk score", "volatility", "drawdown"]):
            return "risk_simulator"
        if any(w in text for w in ["summary", "snapshot", "overview", "at a glance", "goal"]):
            return "summary_agent"
        return "product_explainer"

    # -- Grounded narration (Product Explainer) --------------------------

    def narrate_grounded_answer(self, question: str, chunks: list[dict]) -> dict:
        if self.template_mode or not chunks:
            return self._narrate_grounded_template(question, chunks)

        context = "\n\n".join(f"[{c['doc']} p.{c['page']}] {c['text']}" for c in chunks)
        system = (
            "You are ClariFi's Product Explainer. Answer ONLY using the provided "
            "excerpts. Never give buy/sell advice. Return JSON with exactly "
            "{\"answer\": string, \"key_points\": string[]} and 3-5 key_points."
        )
        try:
            data = self._parse_json(
                self._generate(
                    system=system,
                    contents=f"Question: {question}\n\nExcerpts:\n{context}",
                    max_output_tokens=500,
                    json_output=True,
                )
            )
            if "answer" in data and "key_points" in data:
                return data
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("Gemini narrate_grounded_answer failed, using template: %s", exc)
        return self._narrate_grounded_template(question, chunks)

    @staticmethod
    def _narrate_grounded_template(question: str, chunks: list[dict]) -> dict:
        if not chunks:
            return {
                "answer": "ClariFi couldn't find a document section that directly answers this. Try rephrasing, or upload the relevant document.",
                "key_points": [],
            }
        lead = chunks[0]["text"].strip()
        lead = lead if len(lead) < 320 else lead[:317] + "..."
        return {
            "answer": f"Based on the retrieved sections, {lead}",
            "key_points": [c["text"].strip()[:140] for c in chunks[:4]],
        }

    # -- Live web answer narration ----------------------------------------

    def narrate_web_answer(
        self,
        question: str,
        sources: list[dict],
        tavily_answer: str | None = None,
    ) -> dict:
        """Answer a current question using only retrieved web sources."""
        if self.template_mode:
            if tavily_answer:
                return {
                    "answer": tavily_answer.strip(),
                    "key_points": [
                        f"Source: {item['title']} ({item['domain']})"
                        for item in sources[:4]
                    ],
                }
            return self._narrate_web_template(question, sources)

        context = "\n\n".join(
            f"[{i + 1}] {item['title']} | {item['url']}\n{item.get('content', '')}"
            for i, item in enumerate(sources)
        )
        system = (
            "You are ClariFi's Web Research Agent for financial information. "
            "Answer ONLY from the supplied web sources. Prefer authoritative primary sources. "
            "Do not invent current facts, prices, rates, regulations, or dates. "
            "If sources disagree, say so. Do not give personalized buy/sell advice. "
            "Return JSON with exactly: answer (string) and key_points (array of strings). "
            "Cite factual claims inline using [1], [2], etc. Keep the answer concise and clear."
        )
        try:
            data = self._parse_json(
                self._generate(
                    system=system,
                    contents=f"Question: {question}\n\nWeb sources:\n{context}",
                    max_output_tokens=700,
                    json_output=True,
                )
            )
            if isinstance(data.get("answer"), str) and isinstance(data.get("key_points"), list):
                return data
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("Gemini narrate_web_answer failed, using source template: %s", exc)
        return self._narrate_web_template(question, sources)

    @staticmethod
    def _narrate_web_template(question: str, sources: list[dict]) -> dict:
        if not sources:
            return {
                "answer": "I could not find reliable live web sources for that question.",
                "key_points": [],
            }
        snippets = [
            item.get("content", "").strip().replace("\n", " ")[:220]
            for item in sources[:3]
            if item.get("content")
        ]
        answer = "I found the following current web information relevant to your question: " + " ".join(snippets)
        return {
            "answer": answer,
            "key_points": [f"{item['title']} ({item['domain']})" for item in sources[:4]],
        }

    # -- Portfolio summary narration --------------------------------------

    def narrate_portfolio_summary(self, portfolio: dict) -> dict:
        if self.template_mode:
            return self._narrate_portfolio_template(portfolio)

        system = (
            "You are ClariFi's Summary Agent. Given portfolio metrics, produce a one-page "
            "goal-linked snapshot. NEVER give buy/sell recommendations — use language like "
            "'currently has', 'this exposes you to', 'a key consideration is'. Return JSON "
            "with exactly {\"headline\": string, \"observations\": string[]} with 3-5 observations."
        )
        try:
            data = self._parse_json(
                self._generate(
                    system=system,
                    contents=json.dumps(portfolio),
                    max_output_tokens=400,
                    json_output=True,
                )
            )
            if "headline" in data and "observations" in data:
                return data
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("Gemini narrate_portfolio_summary failed, using template: %s", exc)
        return self._narrate_portfolio_template(portfolio)

    @staticmethod
    def _narrate_portfolio_template(portfolio: dict) -> dict:
        equity_pct = next((a["value"] for a in portfolio["assetMix"] if a["label"] == "Equity"), 0)
        return {
            "headline": f"Your portfolio carries a {portfolio['riskLabel'].lower()} risk profile.",
            "observations": [
                f"Your portfolio currently has {equity_pct}% allocated to equity, {'above' if equity_pct > 55 else 'near'} the moderate-risk average.",
                "This allocation exposes you to greater short-term volatility during market downturns.",
                "A key consideration is your concentration in a small number of sectors.",
                "Historically, portfolios with similar exposure experienced deeper drawdowns during the 2008 and 2020 shocks — see the Stress-Test Time Machine for details.",
            ],
        }

    # -- Stress test narration ---------------------------------------------

    def narrate_stress_test(self, scenario: dict, result: dict) -> str:
        if self.template_mode:
            return self._narrate_stress_test_template(scenario, result)

        system = (
            "You are ClariFi's Risk Simulator. Given a historical shock scenario and "
            "deterministic engine output, write a 2-3 sentence plain-language narration. "
            "Never give buy/sell advice. Respond with plain text only, no JSON."
        )
        try:
            return self._generate(
                system=system,
                contents=json.dumps({"scenario": scenario, "result": result}),
                max_output_tokens=200,
            )
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("Gemini narrate_stress_test failed, using template: %s", exc)
        return self._narrate_stress_test_template(scenario, result)

    @staticmethod
    def _narrate_stress_test_template(scenario: dict, result: dict) -> str:
        return (
            f"{scenario['name']} was a {scenario['character']}. Portfolios with your allocation saw an "
            f"estimated {result['impact_pct']}% impact and a {result['drawdown_pct']}% maximum drawdown, "
            f"with recovery historically taking around {result['recovery_months']} months."
        )


_client: Optional[LLMClient] = None


def get_llm_client() -> LLMClient:
    global _client
    if _client is None:
        _client = LLMClient()
    return _client
