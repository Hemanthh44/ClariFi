from fastapi import APIRouter

from app.compliance.guardrail import apply_guardrail
from app.routers.history import add_history
from app.scam.pattern_matcher import analyze_message, explain
from app.schemas import RedFlag, ScamAnalyzeRequest, ScamAnalyzeResponse

router = APIRouter(prefix="/api/scam", tags=["scam"])


@router.post("/analyze", response_model=ScamAnalyzeResponse)
def analyze(payload: ScamAnalyzeRequest) -> ScamAnalyzeResponse:
    result = analyze_message(payload.message)
    explanation_raw = explain(result["flags"])
    explanation, meta = apply_guardrail(explanation_raw, has_sources=False)

    detection_notes = (
        "Each phrase is matched against a library of regex-based fraud patterns modeled on "
        "recurring SEBI enforcement themes (guaranteed returns, urgency tactics, unregistered "
        "scheme claims, suspicious contact requests). Matched pattern weights sum to a 0-1 score; "
        "no language model is involved in scoring, only in this explanation."
    )

    add_history("Scam message analyzed", f"{result['risk_level']} · {len(result['flags'])} pattern(s) detected")

    return ScamAnalyzeResponse(
        risk_level=result["risk_level"],
        score=result["score"],
        flags=[RedFlag(**f) for f in result["flags"]],
        explanation=explanation,
        detection_notes=detection_notes,
        compliance=meta,
    )
