from functools import lru_cache
from pathlib import Path
import os

from dotenv import load_dotenv
from pydantic_settings import BaseSettings, SettingsConfigDict

# Always load the backend/.env file relative to this file, rather than the
# terminal's current working directory. This prevents API keys from appearing
# as "missing" when uvicorn is started from the project root.
BACKEND_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BACKEND_DIR / ".env"
load_dotenv(ENV_FILE, override=False)


class Settings(BaseSettings):
    """Central configuration for the ClariFi backend."""

    model_config = SettingsConfigDict(
        env_prefix="CLARIFI_",
        env_file=str(ENV_FILE),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    environment: str = "development"
    llm_model: str = "gemini-2.5-flash-lite"
    frontend_origin: str = "http://localhost:5173"
    max_upload_mb: int = 25
    retrieval_top_k: int = 4
    tavily_max_results: int = 6

    # API keys / connection strings intentionally remain unprefixed in
    # backend/.env so they match the names Render, Vercel, etc. expect.
    gemini_api_key: str | None = None
    tavily_api_key: str | None = None
    database_url: str | None = None

    # Cloudflare R2 (S3-compatible) object storage for uploaded documents.
    r2_endpoint_url: str | None = None
    r2_access_key_id: str | None = None
    r2_secret_access_key: str | None = None
    r2_bucket_name: str | None = None
    r2_public_base_url: str | None = None


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    # Pydantic-settings intentionally uses CLARIFI_ for normal settings.
    # These are provider credentials / connection strings and are read
    # explicitly from the already-loaded environment so they work the same
    # way regardless of working directory.
    settings.gemini_api_key = os.getenv("GEMINI_API_KEY") or None
    settings.tavily_api_key = os.getenv("TAVILY_API_KEY") or None
    settings.database_url = os.getenv("DATABASE_URL") or None
    settings.r2_endpoint_url = os.getenv("R2_ENDPOINT_URL") or None
    settings.r2_access_key_id = os.getenv("R2_ACCESS_KEY_ID") or None
    settings.r2_secret_access_key = os.getenv("R2_SECRET_ACCESS_KEY") or None
    settings.r2_bucket_name = os.getenv("R2_BUCKET_NAME") or None
    settings.r2_public_base_url = os.getenv("R2_PUBLIC_BASE_URL") or None
    return settings
