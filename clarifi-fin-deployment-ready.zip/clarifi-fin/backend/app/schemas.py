from typing import Literal, Optional

from pydantic import BaseModel, Field


# ---------- Shared ----------

class Source(BaseModel):
    doc: str
    page: Optional[int] = None
    section: Optional[str] = None
    snippet: str
    url: Optional[str] = None
    domain: Optional[str] = None
    source_type: Literal["document", "web"] = "document"


class ComplianceMeta(BaseModel):
    source_grounded: bool
    explainability_available: bool
    advisory_status: Literal["educational_analytical"] = "educational_analytical"
    disclaimer: str
    flagged_terms: list[str] = Field(default_factory=list)


class AgentTraceStep(BaseModel):
    agent: str
    action: str


# ---------- /api/ask (Orchestrator) ----------

class AskRequest(BaseModel):
    message: str
    document_id: Optional[str] = None
    conversation_id: Optional[str] = None
    web_search: Optional[bool] = None
    action: str = "ask"


class AskResponse(BaseModel):
    agent_used: str
    answer: str
    key_points: list[str] = Field(default_factory=list)
    sources: list[Source] = Field(default_factory=list)
    trace: list[AgentTraceStep] = Field(default_factory=list)
    compliance: ComplianceMeta
    web_searched: bool = False


# ---------- Risk ----------

# ---------- Risk ----------

class AssetAllocation(BaseModel):
    label: Literal["Equity", "Debt", "Others"]
    value: float = Field(ge=0, le=100)


class RiskScoreRequest(BaseModel):
    asset_mix: list[AssetAllocation]


class RiskScoreResponse(BaseModel):
    score: int
    label: str
    breakdown: list[dict]
    factors: list[str]
    compliance: ComplianceMeta


class StressTestRequest(BaseModel):
    scenario_id: Literal[
        "gfc-2008",
        "covid-2020",
        "taper-2013",
    ]
    portfolio_value: float = Field(gt=0)
    asset_mix: list[AssetAllocation]


class AssetImpact(BaseModel):
    label: str
    impact_pct: float


class StressTestResponse(BaseModel):
    scenario_id: str
    scenario_name: str
    period: str
    starting_value: float
    impact_value: float
    impact_pct: float
    drawdown_pct: float
    recovery_months: int
    risk_score_change: int
    asset_impact: list[AssetImpact]
    narrative: str
    compliance: ComplianceMeta

# ---------- Scam Screener ----------

class ScamAnalyzeRequest(BaseModel):
    message: str


class RedFlag(BaseModel):
    label: str
    span: str
    pattern_id: str
    weight: float


class ScamAnalyzeResponse(BaseModel):
    risk_level: Literal["Low Risk", "Suspicious Pattern", "High Risk"]
    score: float
    flags: list[RedFlag]
    explanation: str
    detection_notes: str
    compliance: ComplianceMeta


# ---------- Summary Agent ----------

class PortfolioSummaryResponse(BaseModel):
    headline: str
    observations: list[str]
    compliance: ComplianceMeta


# ---------- Documents / RAG ----------

class DocumentMeta(BaseModel):
    id: str
    name: str
    category: str
    pages: int
    indexed: bool


class DocumentListResponse(BaseModel):
    documents: list[DocumentMeta]

# ---------- Portfolio ----------

class PortfolioSaveRequest(BaseModel):
    value: float = Field(gt=0)
    equity: float = Field(ge=0, le=100)
    debt: float = Field(ge=0, le=100)
    others: float = Field(ge=0, le=100)
    goals_on_track: int = Field(default=0, ge=0)
    goals_total: int = Field(default=0, ge=0)


class PortfolioResponse(BaseModel):
    portfolio: dict
